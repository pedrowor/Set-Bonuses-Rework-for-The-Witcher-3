/*
	Shows the Viper set bonuses in the game UI (item tooltip set block, crafting preview).
	Vanilla hard-codes Viper out of the tooltip (guiTooltipComponent: "setType != EIST_Viper")
	and has no bonus entries for it, so two small wraps add what is missing. No XML involved.
*/

// User-specified descriptions. Do not edit wording without explicit instruction.
function SBT_ViperDesc( tier : int ) : string
{
    if( tier == 1 )
    {
        return "Poisoned weapons deal +5% additional damage or 10% against poison-immune targets for each piece of the Set.";
    }
    return "If using the appropriate oil gain additional 1%/3%/5% Critical Hit Chance, 5%/5%/10% Critical Hit Damage and Take 1%/2%/4% Less Damage from Poisoned Enemies. Bonuses scale with the level of the oil. Standard Oil/Enchanced Oil/Superior Oil.";
}

// The text + active flags the UI reads. Vanilla would look up an undefined bonus for Viper.
@wrapMethod( W3PlayerWitcher ) function SetBonusStatusByType( setType : EItemSetType, out desc1, desc2 : string, out isActive1, isActive2 : bool )
{
	if( setType == EIST_Viper )
	{
		isActive1 = SBT_ViperOn1();
		isActive2 = SBT_ViperOn2();
		desc1 = SBT_ViperDesc( 1 );
		desc2 = SBT_ViperDesc( 2 );
		return;
	}
	wrappedMethod( setType, desc1, desc2, isActive1, isActive2 );
}

// Vanilla builds the tooltip's set block for every set except Viper. Run vanilla first;
// if it skipped a Viper item, build the same block here.
@wrapMethod( W3TooltipComponent ) function AddSetAttributes( itemId : SItemUniqueId, itemInvComponent : CInventoryComponent, out flashDataObj : CScriptedFlashObject ) : bool
{
	var setType : EItemSetType;
	var desc1, desc2 : string;
	var isActive1, isActive2 : bool;
	var list : CScriptedFlashArray;
	var attr : CScriptedFlashObject;

    // Enable the existing set-bonus display for recognised gear at any tier.
    // This changes eligibility only; the description strings are untouched.
    SBT_TagAllTierPiece( itemInvComponent, itemId );

	if( wrappedMethod( itemId, itemInvComponent, flashDataObj ) )
	{
		return true;
	}

	setType = GetWitcherPlayer().GetSetBonusStatus( itemId, desc1, desc2, isActive1, isActive2 );
	if( setType != EIST_Viper || !SBT_ReworkEnabled( EIST_Viper ) )
	{
		return false;
	}

	flashDataObj.SetMemberFlashString( "SetCounter", GetWitcherPlayer().GetSetPartsEquipped( EIST_Viper ) + "/" + theGame.params.ITEMS_REQUIRED_FOR_MAJOR_SET_BONUS );
	list = flashDataObj.CreateFlashArray();

	attr = flashDataObj.CreateFlashObject();
	attr.SetMemberFlashString( "value", theGame.params.ITEMS_REQUIRED_FOR_MINOR_SET_BONUS );
	attr.SetMemberFlashString( "name", desc1 );
	attr.SetMemberFlashBool( "active", isActive1 );
	list.PushBackFlashObject( attr );

	attr = flashDataObj.CreateFlashObject();
	attr.SetMemberFlashString( "value", theGame.params.ITEMS_REQUIRED_FOR_MAJOR_SET_BONUS );
	attr.SetMemberFlashString( "name", desc2 );
	attr.SetMemberFlashBool( "active", isActive2 );
	list.PushBackFlashObject( attr );

	flashDataObj.SetMemberFlashArray( "SetStatsList", list );
	return true;
}
