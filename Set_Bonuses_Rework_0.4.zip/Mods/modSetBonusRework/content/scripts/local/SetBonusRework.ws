/*
	Set Bonus Tweaks - core  (Remastered 5.x, annotation-only, no vanilla files copied)

	  SetBonusTweaks.ws   this file: thresholds, swap table, shared helpers, hooks
	  SBT_Damage.ws       damage-dealt effects (Wolf, Viper, Gryphon, Bear, Forgotten Wolf, Manticore)
	  SBT_Sets.ws         everything else (power stats, signs, damage taken, crits, lifesteal)
	  SBT_Tooltips.ws     English tooltips

	Set names used here:
	  Manticore = Red Wolf set      Forgotten Wolf = Netflix set
	  Wolf = Wolf set               Viper = Viper set (vanilla has no bonuses; added here)
*/

// ============================ CONFIG ============================
function SBT_MinorPieces() : int { return theGame.params.ITEMS_REQUIRED_FOR_MINOR_SET_BONUS; }	// 3
function SBT_MajorPieces() : int { return theGame.params.ITEMS_REQUIRED_FOR_MAJOR_SET_BONUS; }	// 6

// SWAP TABLE: whose pieces drive this set's behaviour (identity by default).
function SBT_PiecesSource( setType : EItemSetType ) : EItemSetType
{
	return setType;
}

// Vanilla bonuses that this mod REPLACES (they are switched off everywhere in the game).
function SBT_IsReplaced( bonus : EItemSetBonus ) : bool
{
	return bonus == EISB_Wolf_1			// vanilla 1% per bleed -> new Wolf 3pc
		|| bonus == EISB_Bear_2			// vanilla quen bonus   -> new Bear 6pc
		|| bonus == EISB_Netflix_1		// vanilla potion time  -> new Forgotten Wolf 3pc
		|| bonus == EISB_Lynx_1
		|| bonus == EISB_Lynx_2
		|| bonus == EISB_RedWolf_2
		|| bonus == EISB_Netflix_2;		// vanilla aard bonus   -> new Forgotten Wolf 6pc
}

// ======================== BONUS <-> SET MAP ======================
function SBT_BonusToSet( bonus : EItemSetBonus ) : EItemSetType
{
	switch( bonus )
	{
		case EISB_Lynx_1:
		case EISB_Lynx_2:		return EIST_Lynx;
		case EISB_Gryphon_1:
		case EISB_Gryphon_2:	return EIST_Gryphon;
		case EISB_Bear_1:
		case EISB_Bear_2:		return EIST_Bear;
		case EISB_Wolf_1:
		case EISB_Wolf_2:		return EIST_Wolf;
		case EISB_RedWolf_1:
		case EISB_RedWolf_2:	return EIST_RedWolf;
		case EISB_Vampire:		return EIST_Vampire;
		case EISB_Netflix_1:
		case EISB_Netflix_2:	return EIST_Netflix;
		default:				return EIST_Undefined;
	}
}

function SBT_IsMajor( bonus : EItemSetBonus ) : bool
{
    return bonus == EISB_Lynx_2 || bonus == EISB_Gryphon_2 || bonus == EISB_Bear_2
        || bonus == EISB_Wolf_2 || bonus == EISB_RedWolf_2 || bonus == EISB_Netflix_2;
}

// Pieces-based "is this bonus on", ignoring the replaced list. All new logic uses this.
function SBT_On( bonus : EItemSetBonus ) : bool
{
	var wp : W3PlayerWitcher;
	var setType : EItemSetType;
	var pieces : int;

	wp = GetWitcherPlayer();
	if( !wp )
	{
		return false;
	}
	setType = SBT_BonusToSet( bonus );
	if( setType == EIST_Undefined )
	{
		return false;
	}
	if( !SBT_ReworkEnabled( setType ) ) return false;
	pieces = wp.GetSetPartsEquipped( setType );
	if( SBT_IsMajor( bonus ) )
	{
		return pieces >= SBT_MajorPieces();
	}
	return pieces >= SBT_MinorPieces();
}

// Viper has no EItemSetBonus entries in vanilla, so it is checked by piece count.
function SBT_ViperPieces() : int
{
	if( !GetWitcherPlayer() )
	{
		return 0;
	}
	return GetWitcherPlayer().GetSetPartsEquipped( EIST_Viper );
}
function SBT_ViperOn1() : bool { return SBT_ReworkEnabled( EIST_Viper ) && SBT_ViperPieces() >= SBT_MinorPieces(); }
function SBT_ViperOn2() : bool { return SBT_ReworkEnabled( EIST_Viper ) && SBT_ViperPieces() >= SBT_MajorPieces(); }

// ======================== SHARED HELPERS =========================
function SBT_Mult( out dmgInfos : array< SRawDamage >, m : float )
{
	var i : int;
	for( i = 0; i < dmgInfos.Size(); i += 1 )
	{
		dmgInfos[i].dmgVal *= m;
	}
}

// Number of bleed instances on an actor (vanilla uses up to 4 bleed types).
function SBT_CountBleeds( a : CActor ) : int
{
	var n : int;
	if( !a )
	{
		return 0;
	}
	if( a.HasBuff( EET_Bleeding ) )  { n += 1; }
	if( a.HasBuff( EET_Bleeding1 ) ) { n += 1; }
	if( a.HasBuff( EET_Bleeding2 ) ) { n += 1; }
	if( a.HasBuff( EET_Bleeding3 ) ) { n += 1; }
	return n;
}

// True when at least one potion (not a decoction/mutagen) is active. Counts once no matter how many.
function SBT_HasPotionBuff() : bool
{
	var buffs : array< CBaseGameplayEffect >;
	var i : int;

	buffs = GetWitcherPlayer().GetPotionBuffs();
	for( i = 0; i < buffs.Size(); i += 1 )
	{
		if( !( ( W3Mutagen_Effect )buffs[i] ) )
		{
			return true;
		}
	}
	return false;
}

// Level (1..3) of an oil: read from the oil item's own 'level' attribute, like vanilla does.
@addMethod( W3Effect_Oil ) function SBT_GetLevel() : int
{
	var min, max : SAbilityAttributeValue;
	theGame.GetDefinitionsManager().GetItemAttributeValueNoRandom( oilItemName, true, 'level', min, max );
	return RoundMath( CalculateAttributeValue( min ) );
}

// Best level of an active oil on one sword. matchCategory = only oils that work on that monster type.
function SBT_OilLevelOnItem( id : SItemUniqueId, category : EMonsterCategory, matchCategory : bool ) : int
{
	var oils : array< W3Effect_Oil >;
	var i, lvl, best : int;

	oils = GetWitcherPlayer().inv.GetOilsAppliedOnItem( id );
	for( i = 0; i < oils.Size(); i += 1 )
	{
		if( oils[i].GetAmmoCurrentCount() > 0 && ( !matchCategory || oils[i].GetMonsterCategory() == category ) )
		{
			lvl = oils[i].SBT_GetLevel();
			if( lvl > best )
			{
				best = lvl;
			}
		}
	}
	return best;
}

// Best oil level across both equipped swords.
function SBT_BestOilLevel( category : EMonsterCategory, matchCategory : bool ) : int
{
	var id : SItemUniqueId;
	var best, lvl : int;

	if( GetWitcherPlayer().GetItemEquippedOnSlot( EES_SteelSword, id ) )
	{
		best = SBT_OilLevelOnItem( id, category, matchCategory );
	}
	if( GetWitcherPlayer().GetItemEquippedOnSlot( EES_SilverSword, id ) )
	{
		lvl = SBT_OilLevelOnItem( id, category, matchCategory );
		if( lvl > best )
		{
			best = lvl;
		}
	}
	return best;
}

// ====================== VIPER ITEM TAGGING =======================
// Vanilla Viper gear has no "set bonus piece" tag, so its pieces are never counted.
// Same idea as the reference mod: tag the item just before the game counts it.
function SBT_IsViperItem( itemName : name ) : bool
{
	var s : string;

	// 1) the item definition already carries the Viper set tag (what the Remastered scripts expect)
	if( theGame.GetDefinitionsManager().ItemHasTag( itemName, theGame.params.ITEM_SET_TAG_VIPER ) )
	{
		return true;
	}
	// 2) fallback by name, like the reference mod
	s = NameToString( itemName );
	return StrContains( s, "EP1 Witcher" ) || StrContains( s, "EP1 Viper" );
}

// Gives a Viper item the tags that make the game count and show it as a set piece.
function SBT_TagViperItem( inv : CInventoryComponent, item : SItemUniqueId )
{
	if( !inv.ItemHasTag( item, theGame.params.ITEM_SET_TAG_BONUS ) )
	{
		inv.AddItemTag( item, theGame.params.ITEM_SET_TAG_BONUS );
	}
	if( !inv.ItemHasTag( item, theGame.params.ITEM_SET_TAG_VIPER ) )
	{
		inv.AddItemTag( item, theGame.params.ITEM_SET_TAG_VIPER );
	}
}

// ============================ HOOKS ==============================
@wrapMethod( W3PlayerWitcher ) function GetSetPartsEquipped( setType : EItemSetType ) : int
{
	return wrappedMethod( SBT_PiecesSource( setType ) );
}

@wrapMethod( W3PlayerWitcher ) function IsSetBonusActive( bonus : EItemSetBonus ) : bool
{
    var original : bool;
    var setType : EItemSetType;
    original = wrappedMethod( bonus );
    setType = SBT_BonusToSet( bonus );
    if( setType == EIST_Undefined || !SBT_ReworkEnabled( setType ) ) return original;
    if( SBT_IsReplaced( bonus ) ) return false;
    return SBT_On( bonus );
}

@wrapMethod( W3PlayerWitcher ) function UpdateItemSetBonuses( item : SItemUniqueId, increment : bool )
{
    // Only tag on equip. Tagging an uncounted item during unequip could
    // incorrectly subtract a different piece from the existing set count.
    if( increment ) SBT_TagAllTierPiece( inv, item );
	wrappedMethod( item, increment );
}

// True only for melee damage performed with a usable steel/silver sword.
function SBT_IsSwordAttack( a : W3Action_Attack ) : bool
{
    var wp : W3PlayerWitcher;
    wp = GetWitcherPlayer();
    return wp && a && a.IsActionMelee() &&
        ( wp.inv.IsItemSteelSwordUsableByPlayer( a.GetWeaponId() ) ||
          wp.inv.IsItemSilverSwordUsableByPlayer( a.GetWeaponId() ) );
}

function SBT_CatTarget( target : CActor ) : bool
{
    return target && ( target.HasBuff( EET_Poison ) || SBT_CountBleeds( target ) > 0 );
}

function SBT_HeldOilLevel( category : EMonsterCategory ) : int
{
    var wp : W3PlayerWitcher;
    wp = GetWitcherPlayer();
    if( !wp ) return 0;
    return SBT_OilLevelOnItem( wp.inv.GetCurrentlyHeldSword(), category, true );
}

function SBT_ActorCategory( actor : CActor ) : EMonsterCategory
{
    var category : EMonsterCategory;
    var soundName : name;
    var teleports, targetable, hitByFists : bool;
    category = MC_NotSet;
    if( actor ) theGame.GetMonsterParamsForActor( actor, category, soundName, teleports, targetable, hitByFists );
    return category;
}

// Bleeding is one qualifying status regardless of its number of stacks.
// Poison is a second, separate qualifying status.
function SBT_CatStatusCount( target : CActor ) : int
{
    var count : int;
    if( !target ) return 0;
    if( SBT_CountBleeds( target ) > 0 ) count += 1;
    if( target.HasBuff( EET_Poison ) ) count += 1;
    return count;
}
