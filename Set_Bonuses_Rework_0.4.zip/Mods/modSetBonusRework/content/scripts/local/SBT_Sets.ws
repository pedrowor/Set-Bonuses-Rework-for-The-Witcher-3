/*
	Non-damage-dealt effects: power stats, signs, damage taken, crits, lifesteal.
*/

// ============================ CONFIG ============================
// Manticore 6pc "small Euphoria": attack power and sign intensity per toxicity point (vanilla Mutation 10 = 0.0075).
function SBT_EuphoriaPerPoint() : float { return 0.0025; }
// Forgotten Wolf 3pc: attack power and sign intensity per piece while any potion is active.
function SBT_FwPotionBonus() : float { return 0.10; }
// Wolf 6pc: share of melee damage healed, per bleed instance on the target.
function SBT_WolfLifesteal() : float { return 0.05; }

// Viper 6pc, by oil level (1 standard, 2 enhanced, 3 superior); all bonuses are PER EQUIPPED VIPER SET PIECE.
function SBT_ViperCritChance( lvl : int ) : float { if( lvl >= 3 ) return 0.05; if( lvl == 2 ) return 0.03; if( lvl == 1 ) return 0.01; return 0; }
function SBT_ViperCritDamage( lvl : int ) : float { if( lvl >= 3 ) return 0.10; if( lvl == 2 ) return 0.05; if( lvl == 1 ) return 0.05; return 0; }
function SBT_ViperDmgTaken( lvl : int ) : float   { if( lvl >= 3 ) return 0.04; if( lvl == 2 ) return 0.02; if( lvl == 1 ) return 0.01; return 0; }

// ===================== POWER STATS / SIGN POWER ==================
function SBT_AddPowerBonuses( out v : SAbilityAttributeValue, signPower : bool )
{
	var wp : W3PlayerWitcher;

	wp = GetWitcherPlayer();
	if( !wp )
	{
		return;
	}
	// Manticore 6pc
	if( signPower && SBT_On( EISB_RedWolf_2 ) )
	{
		v.valueMultiplicative += wp.GetStat( BCS_Toxicity ) * SBT_EuphoriaPerPoint();
	}
	// Forgotten Wolf 3pc (counts once, however many potions are active)
	if( SBT_On( EISB_Netflix_1 ) && SBT_HasPotionBuff() )
	{
		v.valueMultiplicative += SBT_FwPotionBonus() * wp.GetSetPartsEquipped( EIST_Netflix );
	}
}

@wrapMethod( W3PlayerWitcher ) function GetPowerStatValue( stat : ECharacterPowerStats, optional ablName : name, optional ignoreDeath : bool ) : SAbilityAttributeValue
{
	var result : SAbilityAttributeValue;

	result = wrappedMethod( stat, ablName, ignoreDeath );
	if( stat == CPS_AttackPower || stat == CPS_SpellPower )
	{
		SBT_AddPowerBonuses( result, stat == CPS_SpellPower );
	}
	return result;
}

@wrapMethod( W3PlayerWitcher ) function GetTotalSignSpellPower( signSkill : ESkill ) : SAbilityAttributeValue
{
	var sp : SAbilityAttributeValue;

	sp = wrappedMethod( signSkill );
	SBT_AddPowerBonuses( sp, true );

	// Forgotten Wolf 6pc: the next sign after an attack/bomb gets +50%
	if( sbtFwSignReady && SBT_On( EISB_Netflix_2 ) )
	{
		sp.valueMultiplicative += SBT_FwSignBonus();
	}
	return sp;
}

// ========================= SIGN CAST HOOK ========================
@wrapMethod( W3PlayerWitcher ) function OnSignCastPerformed( signType : ESignType, isAlternate : bool )
{

	wrappedMethod( signType, isAlternate );

	// Gryphon: arm the Resonance-style bonus
	if( SBT_On( SBT_GryResonanceBonus() ) )
	{
		sbtGryHits = SBT_GryResonanceHits();
	}

	// Forgotten Wolf 6pc: this sign used up the sign boost; arm the next attack/bomb boost
	if( SBT_On( EISB_Netflix_2 ) )
	{
		sbtFwSignReady = false;
		sbtFwAtkHits = SBT_FwAttackCount();
	}
}

// ===================== DAMAGE TAKEN (Bear, Viper) =================
@wrapMethod( W3PlayerWitcher ) function ReduceDamage( out damageData : W3DamageAction )
{
	var quenBefore : bool;
	var att : CActor;
	var red : float;

	sbtBearBroke = false;
	quenBefore = IsAnyQuenActive();
	wrappedMethod( damageData );

	// Bear: remember that the quen shield broke on this hit
	if( quenBefore && !IsAnyQuenActive() )
	{
		sbtBearBroke = true;
	}

	// Viper 6pc: less damage from poisoned attackers, by matching oil level and equipped Viper pieces
	if( damageData.victim == this && !damageData.IsDoTDamage() && SBT_ViperOn2() )
	{
		att = ( CActor )damageData.attacker;
		if( att && att != this && att.HasBuff( EET_Poison ) )
		{
			red = SBT_ViperDmgTaken( SBT_HeldOilLevel( SBT_ActorCategory( att ) ) ) * SBT_ViperPieces();
			if( red > 0 )
			{
				damageData.processedDmg.vitalityDamage *= 1 - red;
				damageData.processedDmg.essenceDamage *= 1 - red;
			}
		}
	}
}

// ================= AFTER A HIT: Bear trigger, Wolf lifesteal =====
@wrapMethod( W3PlayerWitcher ) function OnProcessActionPost( action : W3DamageAction )
{
	var attackAction : W3Action_Attack;
	var npc : CActor;
	var sp : SAbilityAttributeValue;
	var heal : float;
	var n : int;

	wrappedMethod( action );

	// Bear 6pc: got hurt, or quen broke -> store a bonus from the quen sign intensity
	if( action.victim == this && action.attacker != this && !action.IsDoTDamage() && SBT_On( EISB_Bear_2 ) )
	{
		if( sbtBearBroke || action.processedDmg.vitalityDamage > 0 )
		{
			sp = GetTotalSignSpellPower( S_Magic_4 );
			sbtBearBonus = SBT_BearAttackPerIntensity() * MaxF( 0.f, sp.valueMultiplicative - 1.f );
			sbtBearHits = SBT_BearHits();
			sbtBearExpire = theGame.GetEngineTimeAsSeconds() + SBT_BearTime();
		}
	}
	sbtBearBroke = false;

	// Wolf 6pc: heal 5% of melee damage per bleed instance on the target
	attackAction = ( W3Action_Attack )action;
	if( attackAction && attackAction.attacker == this && attackAction.IsActionMelee() && SBT_On( EISB_Wolf_2 ) )
	{
		npc = ( CActor )attackAction.victim;
		n = SBT_CountBleeds( npc );
		if( npc && n > 0 )
		{
			if( npc.UsesVitality() )
			{
				heal = attackAction.processedDmg.vitalityDamage;
			}
			else if( npc.UsesEssence() )
			{
				heal = attackAction.processedDmg.essenceDamage;
			}
			heal *= SBT_WolfLifesteal() * n;
			if( heal > 0 )
			{
				GainStat( BCS_Vitality, heal );
				PlayEffect( 'drain_energy_caretaker_shovel' );
			}
		}
	}
}

// ======================= VIPER 6pc CRITS ==========================
@wrapMethod( W3PlayerWitcher ) function GetCriticalHitChance( isLightAttack : bool, isHeavyAttack : bool, target : CActor, victimMonsterCategory : EMonsterCategory, isBolt : bool ) : float
{
	var ret : float;

	ret = wrappedMethod( isLightAttack, isHeavyAttack, target, victimMonsterCategory, isBolt );
	if( SBT_ViperOn2() && !isBolt && ( isLightAttack || isHeavyAttack ) )
    {
        ret += SBT_ViperCritChance( SBT_HeldOilLevel( victimMonsterCategory ) ) * SBT_ViperPieces();
    }
    // Bleeding and Poison each grant one copy of the per-piece bonus.
    if( SBT_On( EISB_Lynx_1 ) && !isBolt && ( isLightAttack || isHeavyAttack ) && SBT_CatTarget( target ) )
    {
        ret += 0.03 * GetSetPartsEquipped( EIST_Lynx ) * SBT_CatStatusCount( target );
    }
	return ret;
}

@wrapMethod( W3PlayerWitcher ) function GetCriticalHitDamageBonus( weaponId : SItemUniqueId, victimMonsterCategory : EMonsterCategory, isStrikeAtBack : bool ) : SAbilityAttributeValue
{
	var bonus : SAbilityAttributeValue;

	bonus = wrappedMethod( weaponId, victimMonsterCategory, isStrikeAtBack );
	if( SBT_ViperOn2() && ( inv.IsItemSteelSwordUsableByPlayer( weaponId ) || inv.IsItemSilverSwordUsableByPlayer( weaponId ) ) )
	{
		bonus.valueAdditive += SBT_ViperCritDamage( SBT_OilLevelOnItem( weaponId, victimMonsterCategory, true ) ) * SBT_ViperPieces();
	}
	return bonus;
}
