Set Bonuses Rework

Set Bonuses that are changed for now - Bear / Griffin / Manticore / Wolf / Viper / Forgotten Wolf
Remastered 5.x, annotation-only (no vanilla script files replaced)

How to Install > simply copy Mods/modSetBonusTweaks into <Witcher 3>/mods/ or use TW3 Mod Manager.

WHAT EACH SET DOES:
Wolf School 3pc - Each instance of Bleeding applied to enemies increases sword damage by 3% for each piece of the Set.
Wolf School 6pc - Each Adrenaline Point increases the possible number of Bleeding effects that can be applied to a single enemy. 5% Vitality Drain per bleed Instance.

Bear School 3pc - Vanilla
Bear School 6pc - When a Quen shield shatters or when you take damage gain 0.5% Strong Attack Damage per 1% of Quen sign intensity for the next 2 heavy attacks, lasts 20 seconds.

Griffin School 3pc - Vanilla
Griffin School 6pc - The size of Yrden traps is increased by 40%. 
                     While you are within an Yrden trap, Stamina regeneration is increased by 5/s and Sign Intensity by 100%, and damage taken is reduced by 20%.
                     After casting a Sign, the next three melee attacks deal additional damage equal to 20% Sign intensity.

Manticore School 3pc - Vanilla
Manticore School 6pc - Each point of Toxicity increases damage dealt by swords and Sign Intensity by 0.25%.
                       Each point of Toxicity also increased damage dealt by bombs by +0.5%.
                    
Forgotten Wolf Set 3pc - While Under the effect of any potions increase Sign Intensity and Attack Damage by 10% for each piece of the Set.
Forgotten Wolf Set 6pc - After using a sign your next 3 sword attack or bomb deals +50% more damage.
                         After a Melee attack or a bomb throw increased sign intensity by 50%.

Viper School 3pc - Poisoned weapons deal +5% additional damage or 10% against poison-immune targets for each piece of the Set.
Viper School 6pc - If using the appropriate oil gain additional 1%/3%/5% Critical Chance, 5%/5%/10% Critical Damage and Take 1%/2%/4% Damage from Poisoned Enemies.
                   Bonuses scale with the level of the oil, Standard Oil/Enchanced Oil/Superior Oil.

Cat School 3pc - If the enemy is suffering from a Bleed and/or Poison increase your Critical Hit Chance by 3% and Critical Hit Damage by 6% for each piece of the Set.
Cat School 6pc - 2% Increased Light Attack Speed for each piece of the Set per Adrenaline Point.

to-do:
introduce more potion effects into manticore, potion effectviness per piece of the set if possible.
maybe make viper disable poison immunity, not sure if possible.
forgotten wolf better mix of everything, better incentive to mix things up.
wolf school better bleed chance for those who don't use skill tree reforged.
bear school also takes account vitality or have some sort vitality regen effect after quen breaking
general balance for a equal base from all sets.



changelog
=========

0.4
- Added seven On/Off switches under Options > Mods > Set Bonuses Rework
- All switches default to ON. Each switch controls the whole rework (both 3pc and 6pc). OFF restores the original game/Remaster bonuses for that school.

0.3
- Added Cat School Rework
- Reverted Griffin School Yrden bonuses for now
- Enabled set bonuses for every tier of equipment carrying a recognised school/set tag, including lower tiers and their New Game Plus equivalents.