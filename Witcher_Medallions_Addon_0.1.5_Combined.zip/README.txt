WITCHER MEDALLIONS ADD-ON 0.1.5 - COMBINED INSTALL PACKAGE

Includes restored-items 0.1.4 and grandmaster vendor 0.2, unchanged.
Requires the main Set Bonuses Rework mod (0.5.19 or 0.6), separately installed.

INSTALL
Close the game. Replace these previous add-on folders completely:
Mods/modSBTMedallions
dlc/dlcSBTMedallions
Mods/modSBTMedallionVendors
Copy the Mods and dlc folders from this ZIP into the game directory.
Regenerate affected script merges and restart.
The two internal mod folders are intentional; this is one install package.
Do not install the older standalone packages alongside this version.

Seven invisible mask-slot medallions, green Witcher rarity and school set
bonus tooltips. An equipped medallion adds one matching piece, capped at six.
Vendor access targets Toussaint's dual grandmaster smith/armorer rank
(Lafargue in the standard game). Missing stock replenishes on reopening trade.
Other merchants' medallion stock from the earlier broad test is removed when
trade opens. Player and stash medallions are untouched.
Mods that promote another Toussaint merchant to both highest crafting ranks
may also satisfy the vendor filter.

TEST
First: additem('sbt_medallion_wolf')
Then check Lafargue's buy/sell inventory.
Package contents are verified identical to the two preceding builds.
Spawning and vendor functionality still require in-game verification.
See docs for detailed behavior and test instructions.
