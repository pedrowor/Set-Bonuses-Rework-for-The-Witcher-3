/* Optional grandmaster vendor access for Witcher Medallions.
   Install beside modSBTMedallions and its DLC. No main-mod edits.
   The shop menu calls UpdateLoot before Initialize, so additions survive
   that refresh and are present before the first inventory list is built. */
function SBTMV_ItemName( index : int ) : name
{
    switch( index )
    {
        case 0: return 'sbt_medallion_wolf';
        case 1: return 'sbt_medallion_cat';
        case 2: return 'sbt_medallion_bear';
        case 3: return 'sbt_medallion_griffin';
        case 4: return 'sbt_medallion_manticore';
        case 5: return 'sbt_medallion_viper';
        case 6: return 'sbt_medallion_forgotten_wolf';
    }
    return '';
}

@wrapMethod( W3GuiBaseInventoryComponent ) function Initialize( inv : CInventoryComponent )
{
    var shop : W3GuiShopInventoryComponent;
    var owner : CEntity;
    var craftsman : W3CraftsmanComponent;
    var eligible : bool;
    var area : name;
    var definitions : CDefinitionsManagerAccessor;
    var itemName : name;
    var quantity : int;
    var i : int;

    wrappedMethod( inv );
    shop = (W3GuiShopInventoryComponent)this;
    if( !shop || !inv ) return;
    owner = inv.GetEntity();
    if( !owner ) return;
    craftsman = (W3CraftsmanComponent)owner.GetComponentByClassName( 'W3CraftsmanComponent' );
    area = theGame.GetCommonMapManager().GetCurrentArea();
    eligible = false;
    // ECL_Arch_Master is the highest crafting tier (Blood and Wine
    // grandmaster), not ECL_Grand_Master, the earlier master tier.
    // Both specialties and Toussaint select Lafargue in the standard game.
    if( craftsman && ( area == 'AN_Bob' || area == 'AN_Dlc_Bob' ) )
        eligible = craftsman.GetCraftsmanLevel( ECT_Smith ) == ECL_Arch_Master
            && craftsman.GetCraftsmanLevel( ECT_Armorer ) == ECL_Arch_Master;

    definitions = theGame.GetDefinitionsManager();
    if( !definitions ) return;
    for( i = 0; i < 7; i += 1 )
    {
        itemName = SBTMV_ItemName( i );
        quantity = inv.GetItemQuantityByName( itemName );
        if( eligible )
        {
            // Do not spawn undefined items if the medallion DLC is absent.
            if( definitions.GetItemCategory( itemName ) == 'mask' && quantity == 0 )
                inv.AddAnItem( itemName, 1, true, true );
        }
        else if( quantity > 0 )
        {
            // Migration from the broad 0.1 vendor test. Only shop inventories
            // reach this point; never touch player or stash inventories.
            inv.RemoveItemByName( itemName, quantity );
        }
    }
}
