/* Medallion UI integration for Set Bonuses Rework 0.5.19 / 0.6.
   Resolve school only for tooltips; no native school/SetBonusPiece tags are
   added, so saved counters and the existing +1 contribution stay unchanged. */
@wrapMethod( W3PlayerWitcher ) function SBT_ItemSchool( item : SItemUniqueId, inventory : CInventoryComponent ) : EItemSetType
{
    var school : EItemSetType;
    if( inventory && inventory.IsIdValid( item ) )
    {
        school = SBTM_School( inventory.GetItemName( item ) );
        if( school != EIST_Undefined ) return school;
    }
    return wrappedMethod( item, inventory );
}

// Keep the confirmed-working item XML unchanged. Supply Witcher rarity
// for both newly spawned and previously saved medallions through this query.
@wrapMethod( CInventoryComponent ) function GetItemQuality( itemId : SItemUniqueId ) : int
{
    if( IsIdValid( itemId ) && SBTM_School( GetItemName( itemId ) ) != EIST_Undefined )
        return 5;
    return wrappedMethod( itemId );
}
