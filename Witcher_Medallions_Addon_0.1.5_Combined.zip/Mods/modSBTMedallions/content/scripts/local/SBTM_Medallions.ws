/* Optional add-on for Set Bonuses Rework 0.5.19.
   Only equipped mask-slot medallions contribute. Never change saved counts. */
function SBTM_School( itemName : name ) : EItemSetType
{
    switch( itemName )
    {
        case 'sbt_medallion_wolf': return EIST_Wolf;
        case 'sbt_medallion_cat': return EIST_Lynx;
        case 'sbt_medallion_bear': return EIST_Bear;
        case 'sbt_medallion_griffin': return EIST_Gryphon;
        case 'sbt_medallion_manticore': return EIST_RedWolf;
        case 'sbt_medallion_viper': return EIST_Viper;
        case 'sbt_medallion_forgotten_wolf': return EIST_Netflix;
    }
    return EIST_Undefined;
}

@addMethod( W3PlayerWitcher ) function SBTM_EquippedSchool() : EItemSetType
{
    var item : SItemUniqueId;
    var school : EItemSetType;
    if( !inv ) return EIST_Undefined;
    // Masks can occupy either pocket slot. Native equipment logic prevents
    // wearing two masks; selecting one also bounds malformed saves to +1.
    if( GetItemEquippedOnSlot( EES_Quickslot1, item ) )
    {
        school = SBTM_School( inv.GetItemName( item ) );
        if( school != EIST_Undefined ) return school;
    }
    if( GetItemEquippedOnSlot( EES_Quickslot2, item ) )
        return SBTM_School( inv.GetItemName( item ) );
    return EIST_Undefined;
}

// Wrap the base mod's physical-equipment counter, rather than another wrapper
// of GetSetPartsEquipped. This avoids dependence on wrapper ordering there.
@wrapMethod( W3PlayerWitcher ) function SBT_CountEquippedSetPieces( setType : EItemSetType ) : int
{
    var count : int;
    count = wrappedMethod( setType );
    if( setType != EIST_Undefined && SBTM_EquippedSchool() == setType )
        count = Clamp( count + 1, 0, 6 );
    return count;
}

// Reworks use SBT_On, which reads the counter above. Schools switched OFF use
// vanilla checks against saved counts, so supply an equivalent read-only
// threshold check when their medallion is equipped. Preserve replaced-bonus
// suppression for enabled reworks by leaving their result untouched.
@wrapMethod( W3PlayerWitcher ) function IsSetBonusActive( bonus : EItemSetBonus ) : bool
{
    var result : bool;
    var school : EItemSetType;
    result = wrappedMethod( bonus );
    school = SBT_BonusToSet( bonus );
    if( school != EIST_Undefined && !SBT_ReworkEnabled( school ) && SBTM_EquippedSchool() == school )
    {
        if( SBT_IsMajor( bonus ) )
            return GetSetPartsEquipped( school ) >= theGame.params.ITEMS_REQUIRED_FOR_MAJOR_SET_BONUS;
        return GetSetPartsEquipped( school ) >= theGame.params.ITEMS_REQUIRED_FOR_MINOR_SET_BONUS;
    }
    return result;
}

@addField( W3PlayerWitcher ) var sbtmLastSchool : EItemSetType;

@addMethod( W3PlayerWitcher ) function SBTM_Refresh()
{
    var current, previous : EItemSetType;
    if( !inv || sbtTierWarmup < 5.f || !theGame.IsActive() || theGame.IsBlackscreen() || theGame.IsFading() ) return;
    current = SBTM_EquippedSchool();
    if( current == sbtmLastSchool ) return;
    previous = sbtmLastSchool;
    sbtmLastSchool = current;
    if( previous != EIST_Undefined )
    {
        ManageActiveSetBonuses( previous );
        ManageSetBonusesSoundbanks( previous );
    }
    if( current != EIST_Undefined )
    {
        ManageActiveSetBonuses( current );
        ManageSetBonusesSoundbanks( current );
    }
    SBT_ClearInactiveCharges();
    SBT_UpdateCatSpeed();
    SBT_RefreshPotionStats();
    SBT_UpdateBonusVisuals();
}

@wrapMethod( W3PlayerWitcher ) function EquipItemInGivenSlot( item : SItemUniqueId, slot : EEquipmentSlots, ignoreMounting : bool, optional toHand : bool ) : bool
{
    var result : bool;
    result = wrappedMethod( item, slot, ignoreMounting, toHand );
    SBTM_Refresh();
    return result;
}

@wrapMethod( W3PlayerWitcher ) function UnequipItemFromSlot( slot : EEquipmentSlots, optional reequipped : bool ) : bool
{
    var result : bool;
    result = wrappedMethod( slot, reequipped );
    SBTM_Refresh();
    return result;
}

// Clear the cached school during loading so an equipped medallion is refreshed
// after the base mod's normal five-second warmup, including on save reload.
@wrapMethod( W3PlayerWitcher ) function OnPlayerTickTimer( deltaTime : float )
{
    var result : bool;
    result = wrappedMethod( deltaTime );
    if( sbtTierWarmup < 5.f || !theGame.IsActive() || theGame.IsBlackscreen() || theGame.IsFading() )
        sbtmLastSchool = EIST_Undefined;
    else SBTM_Refresh();
    return result;
}
