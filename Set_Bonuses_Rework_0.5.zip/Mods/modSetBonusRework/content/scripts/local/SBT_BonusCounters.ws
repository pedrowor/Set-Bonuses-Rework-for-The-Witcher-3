/* Read-only tooltip snapshots. Conditional totals are labelled explicitly:
   inspecting an item does not select a combat victim or consume charges. */
function SBT_CounterPercent( value : float ) : string
{
    // Two decimal places preserve small toxicity contributions without noise.
    return NoTrailZeros( (float)RoundMath( value * 10000.f ) / 100.f ) + "%";
}

function SBT_OilCounter( pieces : int, level : int ) : string
{
    return "+" + SBT_CounterPercent( pieces * SBT_ViperCritChance( level ) ) + " chance / +" +
        SBT_CounterPercent( pieces * SBT_ViperCritDamage( level ) ) + " critical damage / " +
        SBT_CounterPercent( pieces * SBT_ViperDmgTaken( level ) ) + " less damage";
}

function SBT_BonusCounter( school : EItemSetType, tier : int ) : string
{
    var wp : W3PlayerWitcher;
    var pieces, required, bleeds, hits, focus : int;
    var bonus, toxicity, remaining : float;
    var power : SAbilityAttributeValue;
    var text, trap : string;
    wp = GetWitcherPlayer();
    if( !wp || !SBT_ReworkEnabled( school ) ) return "";
    // Unchanged native bonuses retain their existing native numerical text.
    if( tier == 1 && ( school == EIST_Bear || school == EIST_Gryphon || school == EIST_RedWolf ) ) return "";
    if( school != EIST_Wolf && school != EIST_Bear && school != EIST_Gryphon &&
        school != EIST_RedWolf && school != EIST_Netflix && school != EIST_Viper && school != EIST_Lynx ) return "";
    pieces = wp.GetSetPartsEquipped( school );
    required = SBT_MinorPieces();
    if( tier == 2 ) required = SBT_MajorPieces();
    if( pieces < required ) return "<br/>Current bonus: inactive (" + pieces + "/" + required + " pieces).";

    switch( school )
    {
        case EIST_Wolf:
            if( tier == 1 )
            {
                bleeds = SBT_CountNearbyEnemyBleeds();
                bonus = MinF( SBT_WolfBleedDmgCap(), bleeds * pieces * SBT_WolfBleedDmg() );
                text = "Current sword damage: +" + SBT_CounterPercent( bonus ) + " / +" + SBT_CounterPercent( SBT_WolfBleedDmgCap() ) + " cap.";
                text += "<br/>" + bleeds + " nearby bleed instances; +" + SBT_CounterPercent( pieces * SBT_WolfBleedDmg() ) + " per instance with " + pieces + " pieces, before cap.";
            }
            else
            {
                focus = Clamp( FloorF( wp.GetStat( BCS_Focus ) ), 0, 3 );
                text = "Current bleed capacity: " + ( 1 + focus ) + " per enemy (" + focus + " Adrenaline Points).";
                text += "<br/>Drain on the enemy hit: " + SBT_CounterPercent( SBT_WolfLifesteal() ) + " per bleed; maximum " + SBT_CounterPercent( SBT_WolfLifestealCap() ) + ".";
            }
            break;
        case EIST_Bear:
            remaining = MaxF( 0.f, wp.sbtBearExpire - theGame.GetEngineTimeAsSeconds() );
            hits = Clamp( wp.sbtBearHits, 0, SBT_BearHits() );
            if( remaining <= 0.f ) hits = 0;
            if( hits > 0 ) bonus = wp.sbtBearBonus;
            else remaining = 0.f;
            text = "Current strong attack bonus: +" + SBT_CounterPercent( bonus ) + "; " + hits + "/" + SBT_BearHits() + " attacks remaining; " + NoTrailZeros( (float)RoundMath( remaining ) ) + "s remaining.";
            break;
        case EIST_Gryphon:
            hits = Clamp( wp.sbtGryHits, 0, SBT_GryResonanceHits() );
            if( hits > 0 )
            {
                power = wp.GetPowerStatValue( CPS_SpellPower );
                bonus = MaxF( 0.f, power.valueMultiplicative ) * SBT_GryResonanceRatio();
            }
            trap = "inactive";
            if( wp.HasBuff( EET_GryphonSetBonusYrden ) ) trap = "active";
            text = "Current melee bonus: +" + SBT_CounterPercent( bonus ) + "; " + hits + "/" + SBT_GryResonanceHits() + " attacks remaining.<br/>Yrden trap bonus: " + trap + ".";
            break;
        case EIST_RedWolf:
            toxicity = MaxF( 0.f, wp.GetStat( BCS_Toxicity ) );
            text = "Current Toxicity: " + NoTrailZeros( (float)RoundMath( toxicity * 100.f ) / 100.f ) + ".";
            text += "<br/>Sword attack power / Sign Intensity: +" + SBT_CounterPercent( toxicity * SBT_EuphoriaPerPoint() ) + "; bomb damage: +" + SBT_CounterPercent( toxicity * SBT_RWBombPerToxicity() ) + ".";
            break;
        case EIST_Netflix:
            if( tier == 1 )
            {
                if( SBT_HasPotionBuff() ) bonus = pieces * SBT_FwPotionBonus();
                text = "Current attack power / Sign Intensity: +" + SBT_CounterPercent( bonus ) + ".<br/>With an active potion: +" + SBT_CounterPercent( pieces * SBT_FwPotionBonus() ) + " total from " + pieces + " pieces.";
            }
            else
            {
                hits = Clamp( wp.sbtFwAtkHits, 0, SBT_FwAttackCount() );
                if( hits > 0 ) bonus = SBT_FwAttackBonus();
                text = "Current sword/bomb bonus: +" + SBT_CounterPercent( bonus ) + "; " + hits + "/" + SBT_FwAttackCount() + " charges remaining.";
                bonus = 0.f;
                if( wp.sbtFwSignReady ) bonus = SBT_FwSignBonus();
                text += "<br/>Readied Sign Intensity bonus: +" + SBT_CounterPercent( bonus ) + ".";
            }
            break;
        case EIST_Viper:
            if( tier == 1 )
                text = "With " + pieces + " pieces: +" + SBT_CounterPercent( pieces * SBT_ViperPoisonDmg() ) + " against poisoned targets / +" + SBT_CounterPercent( pieces * SBT_ViperImmuneDmg() ) + " against poison-immune targets.";
            else
            {
                text = "Conditional totals with " + pieces + " pieces and matching oil (protection requires a poisoned attacker):";
                text += "<br/>Standard: " + SBT_OilCounter( pieces, 1 ) + ".";
                text += "<br/>Enhanced: " + SBT_OilCounter( pieces, 2 ) + ".";
                text += "<br/>Superior: " + SBT_OilCounter( pieces, 3 ) + ".";
            }
            break;
        case EIST_Lynx:
            if( tier == 1 )
            {
                text = "With " + pieces + " pieces, bleed OR poison: +" + SBT_CounterPercent( .03 * pieces ) + " critical chance / +" + SBT_CounterPercent( .06 * pieces ) + " critical damage.";
                text += "<br/>Bleed AND poison: +" + SBT_CounterPercent( .06 * pieces ) + " critical chance / +" + SBT_CounterPercent( .12 * pieces ) + " critical damage.";
            }
            else
            {
                focus = FloorF( wp.GetStat( BCS_Focus ) );
                bonus = MaxF( 0.f, .02 * pieces * focus );
                text = "Current bonus during light sword attacks: +" + SBT_CounterPercent( bonus ) + " speed (" + focus + " full Adrenaline Points).";
                text += "<br/>Per Adrenaline Point with " + pieces + " pieces: +" + SBT_CounterPercent( .02 * pieces ) + ".";
            }
            break;
    }
    if( text == "" ) return "";
    return "<br/>" + text;
}
