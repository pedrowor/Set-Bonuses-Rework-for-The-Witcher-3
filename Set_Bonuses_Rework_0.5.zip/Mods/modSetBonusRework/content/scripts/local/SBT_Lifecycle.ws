/* Observe resolved actions for effects that depend on actual damage or shield
   destruction. The native OnProcessActionPost callback belongs to the attacker. */
@wrapMethod( W3DamageManagerProcessor ) function ProcessAction( act : W3DamageAction )
{
    var wp : W3PlayerWitcher;
    var victim : CActor;
    var attack : W3Action_Attack;
    var incoming, drain, quenBefore : bool;
    var healthBefore, healthLost, dealt, heal : float;
    var bleedCount : int;
    wp = GetWitcherPlayer();
    if( wp && act && !act.GetSimulateOnly() )
    {
        victim = (CActor)act.victim;
        incoming = act.victim == wp && SBT_On( EISB_Bear_2 );
        if( incoming ) quenBefore = wp.IsAnyQuenActive();
        attack = (W3Action_Attack)act;
        drain = attack && attack.attacker == wp && victim && victim != wp &&
            attack.IsActionMelee() && !act.IsDoTDamage() && victim.IsAlive() && SBT_On( EISB_Wolf_2 );
        if( drain )
        {
            healthBefore = MaxF( 0.f, victim.GetHealth() );
            bleedCount = SBT_CountBleeds( victim );
        }
    }
    wrappedMethod( act );
    if( !wp || !act || act.GetSimulateOnly() ) return;
    // EndsQuen is set during shield processing; actual FinishQuen occurs later.
    if( incoming && wp.IsAlive() && SBT_On( EISB_Bear_2 ) &&
        ( act.processedDmg.vitalityDamage > 0.f || ( quenBefore && act.EndsQuen() ) ) )
        wp.SBT_ArmBearBonus();
    if( drain && wp.IsAlive() && SBT_On( EISB_Wolf_2 ) )
    {
        // Retain pre-hit bleeds when a killing blow removes the victim's buffs.
        bleedCount = Max( bleedCount, SBT_CountBleeds( victim ) );
        healthLost = MaxF( 0.f, healthBefore - MaxF( 0.f, victim.GetHealth() ) );
        if( victim.UsesVitality() ) dealt = act.processedDmg.vitalityDamage;
        else if( victim.UsesEssence() ) dealt = act.processedDmg.essenceDamage;
        heal = MinF( MaxF( 0.f, dealt ), healthLost ) * MinF( SBT_WolfLifestealCap(), SBT_WolfLifesteal() * bleedCount );
        if( heal > 0.f )
        {
            wp.GainStat( BCS_Vitality, heal );
            wp.PlayEffect( 'drain_energy_caretaker_shovel' );
        }
    }
}

@addMethod( W3PlayerWitcher ) function SBT_ArmBearBonus()
{
    var power : SAbilityAttributeValue;
    power = GetTotalSignSpellPower( S_Magic_4 );
    sbtBearBonus = SBT_BearAttackPerIntensity() * MaxF( 0.f, power.valueMultiplicative );
    sbtBearHits = SBT_BearHits();
    sbtBearExpire = theGame.GetEngineTimeAsSeconds() + SBT_BearTime();
}

@addField( W3PlayerWitcher ) var sbtFwWasActive : bool;

@addMethod( W3PlayerWitcher ) function SBT_ClearInactiveCharges()
{
    if( !SBT_On( EISB_Bear_2 ) || theGame.GetEngineTimeAsSeconds() > sbtBearExpire )
    {
        sbtBearHits = 0;
        sbtBearBonus = 0.f;
        sbtBearExpire = 0.f;
        sbtBearSwing = false;
    }
    if( !SBT_On( EISB_Gryphon_2 ) )
    {
        sbtGryHits = 0;
        sbtGrySwing = false;
    }
    if( !SBT_On( EISB_Netflix_2 ) )
    {
        sbtFwAtkHits = 0;
        sbtFwSignReady = false;
        sbtFwSwing = false;
        // A previously thrown bomb must not regain its bonus after re-equipping.
        if( sbtFwWasActive ) sbtFwSwitchId += 1;
        sbtFwWasActive = false;
    }
    else sbtFwWasActive = true;
    if( SBT_ReworkEnabled( EIST_Lynx ) && HasBuff( EET_LynxSetBonus ) )
        RemoveBuff( EET_LynxSetBonus );
}

// The native manager removes an already-present Yrden buff even when the
// 6-piece bonus is still active. Reconcile it with current trap occupancy.
@wrapMethod( W3PlayerWitcher ) function ManageActiveSetBonuses( setType : EItemSetType )
{
    var i : int;
    wrappedMethod( setType );
    if( setType != EIST_Gryphon || !IsSetBonusActive( EISB_Gryphon_2 ) || HasBuff( EET_GryphonSetBonusYrden ) ) return;
    for( i = 0; i < yrdenEntities.Size(); i += 1 )
    {
        if( yrdenEntities[i] && yrdenEntities[i].GetIsPlayerInside() && !yrdenEntities[i].IsAlternateCast() )
        {
            AddEffectDefault( EET_GryphonSetBonusYrden, this, "GryphonSetBonusYrden" );
            return;
        }
    }
}

// Critical chance queries do not receive a weapon ID. Preserve the action's
// actual weapon across the native calculation instead of guessing from hands.
@addField( W3PlayerWitcher ) var sbtCriticalContext : bool;
@addField( W3PlayerWitcher ) var sbtCriticalWeapon : SItemUniqueId;

@addMethod( W3PlayerWitcher ) function SBT_CriticalWeapon() : SItemUniqueId
{
    if( sbtCriticalContext ) return sbtCriticalWeapon;
    return inv.GetCurrentlyHeldSword();
}

@wrapMethod( W3DamageManagerProcessor ) function ProcessCriticalHitCheck()
{
    var wp : W3PlayerWitcher;
    var previousContext : bool;
    var previousWeapon : SItemUniqueId;
    wp = GetWitcherPlayer();
    if( wp )
    {
        previousContext = wp.sbtCriticalContext;
        previousWeapon = wp.sbtCriticalWeapon;
        wp.sbtCriticalContext = true;
        wp.sbtCriticalWeapon = GetInvalidUniqueId();
        if( attackAction && attackAction.attacker == wp ) wp.sbtCriticalWeapon = attackAction.GetWeaponId();
    }
    wrappedMethod();
    if( wp )
    {
        wp.sbtCriticalContext = previousContext;
        wp.sbtCriticalWeapon = previousWeapon;
    }
}
