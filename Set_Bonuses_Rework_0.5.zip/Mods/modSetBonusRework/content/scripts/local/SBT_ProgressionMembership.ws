// Exact equipment names from the supplied Manticore Progression mod.
// Manticore uses the Red Wolf school internally.
function SBT_IsManticoreProgressionItem( itemName : name ) : bool
{
    switch( itemName )
    {
        case 'Manticore Armor 1':
        case 'Manticore Armor 2':
        case 'Manticore Armor 3':
        case 'Manticore Armor 4':
        case 'Manticore Boots 1':
        case 'Manticore Boots 2':
        case 'Manticore Boots 3':
        case 'Manticore Boots 4':
        case 'Manticore Gloves 1':
        case 'Manticore Gloves 2':
        case 'Manticore Gloves 3':
        case 'Manticore Gloves 4':
        case 'Manticore Pants 1':
        case 'Manticore Pants 2':
        case 'Manticore Pants 3':
        case 'Manticore Pants 4':
        case 'Manticore silver sword 1':
        case 'Manticore silver sword 2':
        case 'Manticore silver sword 3':
        case 'Manticore silver sword 4':
        case 'Manticore steel sword 1':
        case 'Manticore steel sword 2':
        case 'Manticore steel sword 3':
        case 'Manticore steel sword 4':
        case 'NGP Manticore Armor 1':
        case 'NGP Manticore Armor 2':
        case 'NGP Manticore Armor 3':
        case 'NGP Manticore Armor 4':
        case 'NGP Manticore Boots 1':
        case 'NGP Manticore Boots 2':
        case 'NGP Manticore Boots 3':
        case 'NGP Manticore Boots 4':
        case 'NGP Manticore Gloves 1':
        case 'NGP Manticore Gloves 2':
        case 'NGP Manticore Gloves 3':
        case 'NGP Manticore Gloves 4':
        case 'NGP Manticore Pants 1':
        case 'NGP Manticore Pants 2':
        case 'NGP Manticore Pants 3':
        case 'NGP Manticore Pants 4':
        case 'NGP Manticore silver sword 1':
        case 'NGP Manticore silver sword 2':
        case 'NGP Manticore silver sword 3':
        case 'NGP Manticore silver sword 4':
        case 'NGP Manticore steel sword 1':
        case 'NGP Manticore steel sword 2':
        case 'NGP Manticore steel sword 3':
        case 'NGP Manticore steel sword 4':
            return true;
    }
    return false;
}
