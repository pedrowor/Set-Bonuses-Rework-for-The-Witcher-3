/* Cat 6pc: 2% per equipped Cat piece per FULL Adrenaline Point.
   A private animation causer is updated in place and removed as soon as the
   action stops qualifying. Never reset another mod's causer ID. */
@addField( CR4Player ) var sbtCatSpeedId : int;
@addField( CR4Player ) var sbtCatSpeedActive : bool;
@addField( CR4Player ) var sbtCatSpeedApplied : float;

@addMethod( CR4Player ) function SBT_UpdateCatSpeed()
{
    var wp : W3PlayerWitcher;
    var wanted : float;
    wp = ( W3PlayerWitcher )this;
    wanted = 1.f;
    if( wp && IsAlive() && !theGame.IsDialogOrCutscenePlaying() &&
        IsInCombatAction() && GetCombatAction() == EBAT_LightAttack &&
        ( IsWeaponHeld( 'steelsword' ) || IsWeaponHeld( 'silversword' ) ) && SBT_On( EISB_Lynx_2 ) )
    {
        wanted += 0.02 * wp.GetSetPartsEquipped( EIST_Lynx ) * FloorF( GetStat( BCS_Focus ) );
    }
    if( wanted <= 1.f )
    {
        if( sbtCatSpeedActive ) ResetAnimationSpeedMultiplier( sbtCatSpeedId );
        sbtCatSpeedActive = false;
        sbtCatSpeedApplied = 1.f;
        return;
    }
    if( !sbtCatSpeedActive )
    {
        sbtCatSpeedId = SetAnimationSpeedMultiplier( wanted, -1 );
        sbtCatSpeedActive = true;
    }
    else if( wanted != sbtCatSpeedApplied )
    {
        sbtCatSpeedId = SetAnimationSpeedMultiplier( wanted, sbtCatSpeedId );
    }
    sbtCatSpeedApplied = wanted;
}

@wrapMethod( CR4LocomotionPlayerControllerScript ) function UpdateLocomotion()
{
    wrappedMethod();
    if( player ) player.SBT_UpdateCatSpeed();
}

// These hooks apply/reset immediately at the action transition; locomotion
// also checks equipment, Adrenaline, cutscenes and death every update.
@wrapMethod( CR4Player ) function SetCombatAction( action : EBufferActionType )
{
    wrappedMethod( action );
    SBT_UpdateCatSpeed();
}

@wrapMethod( CPlayer ) function SetBIsInCombatAction( flag : bool )
{
    var p : CR4Player;
    wrappedMethod( flag );
    p = ( CR4Player )this;
    if( p ) p.SBT_UpdateCatSpeed();
}
