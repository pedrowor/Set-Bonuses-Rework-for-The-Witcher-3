/* Include Manticore's existing sword attack-power contribution in the offense
   statistics. The actual combat bonus remains in the damage processor. */
@addField( W3PlayerWitcher ) var sbtManticoreStatsPreview : bool;

@wrapMethod( W3PlayerWitcher ) function GetOffenseStatsList( optional hackMode : int ) : SPlayerOffenseStats
{
    var original, preview : SPlayerOffenseStats;
    var pass : int;
    // Keep one wrappedMethod call site: the annotation processor in the
    // reported installation does not resolve additional occurrences.
    for( pass = 0; pass < 2; pass += 1 )
    {
        preview = wrappedMethod( hackMode );
        if( pass == 0 )
        {
            original = preview;
            // Nested queries preserve the caller's existing preview context.
            if( sbtManticoreStatsPreview || !abilityManager || !abilityManager.IsInitialized() ||
                !SBT_On( EISB_RedWolf_2 ) || GetStat( BCS_Toxicity ) <= 0.f )
                return original;
            sbtManticoreStatsPreview = true;
        }
    }

    // Reuse the game's own fast/strong/critical/DPS formulas. Its offense
    // builder reuses attack power for crossbows, so retain their original data.
    sbtManticoreStatsPreview = false;
    preview.crossbowSteelDmg = original.crossbowSteelDmg;
    preview.crossbowSilverDmg = original.crossbowSilverDmg;
    preview.crossbowSteelDmgType = original.crossbowSteelDmgType;
    preview.crossbowCritChance = original.crossbowCritChance;
    return preview;
}
