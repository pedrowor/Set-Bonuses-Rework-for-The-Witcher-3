/* One switch per school: ON uses the rework, OFF restores original bonuses.
   Defaults are ON. Combat reads applied settings; the cache drives cleanup.
   Existing all-tier eligibility and bonus description strings are unchanged. */
@addField( CR4Game ) var sbtMenuFlags : array<bool>;
@addField( CR4Game ) var sbtMenuLoaded : bool;
@addField( W3PlayerWitcher ) var sbtMenuCheck : float;
@addField( W3PlayerWitcher ) var sbtFwSwitchId : int;
@addField( W3Petard ) var sbtFwSwitchId : int;

function SBT_ReworkEnabled( setType : EItemSetType ) : bool
{
    var cfg : CInGameConfigWrapper;
    // The gameplay timer may pause in some player states. Never let its cached
    // value keep a combat bonus enabled after the applied setting is OFF.
    cfg = theGame.GetInGameConfigWrapper();
    if( cfg && cfg.GetGroupIdx( "SBT_Reworks" ) >= 0 )
    {
        switch( setType )
        {
            case EIST_Wolf: return SBT_ReadSchoolSwitch( cfg, 'WolfRework' );
            case EIST_Lynx: return SBT_ReadSchoolSwitch( cfg, 'CatRework' );
            case EIST_Bear: return SBT_ReadSchoolSwitch( cfg, 'BearRework' );
            case EIST_Gryphon: return SBT_ReadSchoolSwitch( cfg, 'GriffinRework' );
            case EIST_RedWolf: return SBT_ReadSchoolSwitch( cfg, 'ManticoreRework' );
            case EIST_Netflix: return SBT_ReadSchoolSwitch( cfg, 'ForgottenWolfRework' );
            case EIST_Viper: return SBT_ReadSchoolSwitch( cfg, 'ViperRework' );
        }
    }
    if( !theGame.sbtMenuLoaded || (int)setType < 0 || (int)setType >= theGame.sbtMenuFlags.Size() ) return true;
    return theGame.sbtMenuFlags[setType];
}

function SBT_ReadSchoolSwitch( cfg : CInGameConfigWrapper, option : name ) : bool
{
    var value : string;
    if( !cfg || cfg.GetGroupIdx( "SBT_Reworks" ) < 0 ) return true;
    value = StrLower( cfg.GetVarValue( 'SBT_Reworks', option ) );
    if( value == "false" || value == "0" ) return false;
    if( value == "true" || value == "1" ) return true;
    // Missing or unrecognised values use the declared ON default. Do not
    // silently disable all reworks because of an unexpected setting string.
    return true;
}

function SBT_DefaultSchoolSwitch( cfg : CInGameConfigWrapper, option : name ) : bool
{
    if( cfg.GetVarValue( 'SBT_Reworks', option ) != "" ) return false;
    cfg.SetVarValue( 'SBT_Reworks', option, "true" );
    return true;
}

function SBT_InitMenuDefaults()
{
    var cfg : CInGameConfigWrapper;
    var changed : bool;
    cfg = theGame.GetInGameConfigWrapper();
    if( !cfg || cfg.GetGroupIdx( "SBT_Reworks" ) < 0 ) return;
    if( SBT_DefaultSchoolSwitch( cfg, 'WolfRework' ) ) changed = true;
    if( SBT_DefaultSchoolSwitch( cfg, 'CatRework' ) ) changed = true;
    if( SBT_DefaultSchoolSwitch( cfg, 'BearRework' ) ) changed = true;
    if( SBT_DefaultSchoolSwitch( cfg, 'GriffinRework' ) ) changed = true;
    if( SBT_DefaultSchoolSwitch( cfg, 'ManticoreRework' ) ) changed = true;
    if( SBT_DefaultSchoolSwitch( cfg, 'ForgottenWolfRework' ) ) changed = true;
    if( SBT_DefaultSchoolSwitch( cfg, 'ViperRework' ) ) changed = true;
    if( changed ) theGame.SaveUserSettings();
}

// This hook also initializes defaults when Options is opened at the main menu.
// Preserve the original event result, as required by event annotations.
@wrapMethod( CR4CommonMainMenuBase ) function OnConfigUI()
{
    SBT_InitMenuDefaults();
    return wrappedMethod();
}

@addMethod( W3PlayerWitcher ) function SBT_ApplySchoolSwitch( setType : EItemSetType, enabled : bool )
{
    // Clear custom charges on every transition so OFF -> ON cannot revive them.
    switch( setType )
    {
        case EIST_Bear:
            sbtBearHits = 0;
            sbtBearBonus = 0.f;
            sbtBearExpire = 0.f;
            sbtBearSwing = false;
            break;
        case EIST_Gryphon:
            sbtGryHits = 0;
            sbtGrySwing = false;
            break;
        case EIST_Netflix:
            sbtFwAtkHits = 0;
            sbtFwSignReady = false;
            sbtFwSwing = false;
            // Invalidate boosts captured by bombs thrown before the switch.
            sbtFwSwitchId += 1;
            break;
        case EIST_Lynx:
            if( enabled && HasBuff( EET_LynxSetBonus ) ) RemoveBuff( EET_LynxSetBonus );
            SBT_UpdateCatSpeed();
            break;
    }
    ManageActiveSetBonuses( setType );
    ManageSetBonusesSoundbanks( setType );
}

@addMethod( W3PlayerWitcher ) function SBT_RefreshSchoolSwitch( cfg : CInGameConfigWrapper, setType : EItemSetType, option : name )
{
    var g : CR4Game;
    var enabled : bool;
    // Write through a local object reference; theGame is a const global.
    g = theGame;
    enabled = SBT_ReadSchoolSwitch( cfg, option );
    if( g.sbtMenuFlags[setType] == enabled ) return;
    g.sbtMenuFlags[setType] = enabled;
    SBT_ApplySchoolSwitch( setType, enabled );
}

// Poll only during visible gameplay. Options may buffer values until Apply.
// Once applied, settings take effect on the next half-second refresh.
@addMethod( W3PlayerWitcher ) function SBT_ReworkMenuTick( deltaTime : float )
{
    var g : CR4Game;
    var cfg : CInGameConfigWrapper;
    var i : int;
    g = theGame;
    if( !theGame.IsActive() || theGame.IsBlackscreen() || theGame.IsFading() || !theGame.GetHud() ) return;
    sbtMenuCheck -= deltaTime;
    if( sbtMenuCheck > 0.f ) return;
    sbtMenuCheck = 0.5f;
    if( !g.sbtMenuLoaded )
    {
        g.sbtMenuFlags.Resize( EnumGetMax( 'EItemSetType' ) + 1 );
        for( i = 0; i < g.sbtMenuFlags.Size(); i += 1 ) g.sbtMenuFlags[i] = true;
        g.sbtMenuLoaded = true;
    }
    SBT_InitMenuDefaults();
    cfg = theGame.GetInGameConfigWrapper();
    SBT_RefreshSchoolSwitch( cfg, EIST_Wolf, 'WolfRework' );
    SBT_RefreshSchoolSwitch( cfg, EIST_Lynx, 'CatRework' );
    SBT_RefreshSchoolSwitch( cfg, EIST_Bear, 'BearRework' );
    SBT_RefreshSchoolSwitch( cfg, EIST_Gryphon, 'GriffinRework' );
    SBT_RefreshSchoolSwitch( cfg, EIST_RedWolf, 'ManticoreRework' );
    SBT_RefreshSchoolSwitch( cfg, EIST_Netflix, 'ForgottenWolfRework' );
    SBT_RefreshSchoolSwitch( cfg, EIST_Viper, 'ViperRework' );
    SBT_ClearInactiveCharges();
}
