/* Set blocks use the actual item inventory and live equipped counts. */

// User-specified descriptions. Do not edit wording without explicit instruction.
function SBT_ViperDesc( tier : int ) : string
{
    if( tier == 1 )
    {
        return "Poisoned weapons deal +5% additional damage or 10% against poison-immune targets for each piece of the Set.";
    }
    return "If using the appropriate oil gain additional 1%/3%/5% Critical Hit Chance, 5%/5%/10% Critical Hit Damage and Take 1%/2%/4% Less Damage from Poisoned Enemies.<br/>Bonuses scale with the level of the oil.<br/>Standard Oil/Enchanced Oil/Superior Oil.";
}

// Reset both output flags; native code only sets them true and uses saved counts.
@wrapMethod( W3PlayerWitcher ) function SetBonusStatusByType( setType : EItemSetType, out desc1, desc2 : string, out isActive1, isActive2 : bool )
{
    isActive1 = false;
    isActive2 = false;
    if( setType == EIST_Viper )
    {
        desc1 = "";
        desc2 = "";
        if( !SBT_ReworkEnabled( EIST_Viper ) ) return;
        desc1 = SBT_ViperDesc( 1 );
        desc2 = SBT_ViperDesc( 2 );
        isActive1 = SBT_ViperOn1();
        isActive2 = SBT_ViperOn2();
        return;
    }
    wrappedMethod( setType, desc1, desc2, isActive1, isActive2 );
    if( setType == EIST_Undefined ) return;
    isActive1 = GetSetPartsEquipped( setType ) >= SBT_MinorPieces();
    isActive2 = desc2 != "" && GetSetPartsEquipped( setType ) >= SBT_MajorPieces();
}

// Resolve school membership in the inventory that actually owns the item.
@addMethod( W3PlayerWitcher ) function SBT_ItemSchool( item : SItemUniqueId, inventory : CInventoryComponent ) : EItemSetType
{
    var itemName : name;
    if( !inventory || !inventory.IsIdValid( item ) ) return EIST_Undefined;
    itemName = inventory.GetItemName( item );
    if( SBT_IsManticoreProgressionItem( itemName ) ) return EIST_RedWolf;
    if( SBT_IsViperItem( itemName ) ) return EIST_Viper;
    if( inventory.ItemHasTag( item, theGame.params.ITEM_SET_TAG_BEAR ) ) return EIST_Bear;
    if( inventory.ItemHasTag( item, theGame.params.ITEM_SET_TAG_GRYPHON ) ) return EIST_Gryphon;
    if( inventory.ItemHasTag( item, theGame.params.ITEM_SET_TAG_LYNX ) ) return EIST_Lynx;
    if( inventory.ItemHasTag( item, theGame.params.ITEM_SET_TAG_WOLF ) ) return EIST_Wolf;
    if( inventory.ItemHasTag( item, theGame.params.ITEM_SET_TAG_RED_WOLF ) ) return EIST_RedWolf;
    if( inventory.ItemHasTag( item, theGame.params.ITEM_SET_TAG_VAMPIRE ) ) return EIST_Vampire;
    if( inventory.ItemHasTag( item, theGame.params.ITEM_SET_TAG_VIPER ) ) return EIST_Viper;
    if( inventory.ItemHasTag( item, theGame.params.ITEM_SET_TAG_NETFLIX ) ) return EIST_Netflix;
    return EIST_Undefined;
}

@addMethod( W3PlayerWitcher ) function SBT_ItemSetStatus( item : SItemUniqueId, inventory : CInventoryComponent, out desc1, desc2 : string, out active1, active2 : bool ) : EItemSetType
{
    var school : EItemSetType;
    desc1 = "";
    desc2 = "";
    active1 = false;
    active2 = false;
    school = SBT_ItemSchool( item, inventory );
    // Viper has no native bonus enum entries. Supply its block directly so
    // a replacement of the native status query cannot discard these strings.
    if( school == EIST_Viper )
    {
        if( SBT_ReworkEnabled( EIST_Viper ) )
        {
            desc1 = SBT_ViperDesc( 1 );
            desc2 = SBT_ViperDesc( 2 );
            active1 = SBT_ViperOn1();
            active2 = SBT_ViperOn2();
        }
        return school;
    }
    if( school != EIST_Undefined ) SetBonusStatusByType( school, desc1, desc2, active1, active2 );
    return school;
}

@wrapMethod( W3TooltipComponent ) function AddSetAttributes( itemId : SItemUniqueId, itemInvComponent : CInventoryComponent, out flashDataObj : CScriptedFlashObject ) : bool
{
    var original : bool;
    SBT_TagAllTierPiece( itemInvComponent, itemId );
    original = wrappedMethod( itemId, itemInvComponent, flashDataObj );
    if( SBT_WriteSetBlock( itemId, itemInvComponent, flashDataObj ) ) return true;
    return original;
}

// Replace only the two set fields. Repeated calls produce the same block,
// rather than appending duplicate rows or rebuilding the whole item tooltip.
@addMethod( W3TooltipComponent ) function SBT_WriteSetBlock( itemId : SItemUniqueId, itemInvComponent : CInventoryComponent, out flashDataObj : CScriptedFlashObject ) : bool
{
    var wp : W3PlayerWitcher;
    var active1, active2 : bool;
    var school : EItemSetType;
    var desc1, desc2 : string;
    var list : CScriptedFlashArray;
    var attr : CScriptedFlashObject;
    wp = GetWitcherPlayer();
    if( !wp || !flashDataObj || !itemInvComponent || !itemInvComponent.IsIdValid( itemId ) ) return false;
    school = wp.SBT_ItemSetStatus( itemId, itemInvComponent, desc1, desc2, active1, active2 );
    if( school == EIST_Undefined ) return false;
    if( school == EIST_Viper && !SBT_ReworkEnabled( EIST_Viper ) ) return false;
    flashDataObj.SetMemberFlashString( "SetCounter", wp.GetSetPartsEquipped( school ) + "/" + SBT_MajorPieces() );
    list = flashDataObj.CreateFlashArray();
    if( desc1 != "" )
    {
        attr = flashDataObj.CreateFlashObject();
        attr.SetMemberFlashString( "value", SBT_MinorPieces() );
        attr.SetMemberFlashString( "name", desc1 + SBT_BonusCounter( school, 1 ) );
        attr.SetMemberFlashBool( "active", active1 );
        list.PushBackFlashObject( attr );
    }
    if( desc2 != "" )
    {
        attr = flashDataObj.CreateFlashObject();
        attr.SetMemberFlashString( "value", SBT_MajorPieces() );
        attr.SetMemberFlashString( "name", desc2 + SBT_BonusCounter( school, 2 ) );
        attr.SetMemberFlashBool( "active", active2 );
        list.PushBackFlashObject( attr );
    }
    flashDataObj.SetMemberFlashArray( "SetStatsList", list );
    return true;
}

@wrapMethod( W3TooltipComponent ) function GetBaseItemData( item : SItemUniqueId, itemInvComponent : CInventoryComponent, optional isShopItem : bool, optional compareWithItem : SItemUniqueId, optional compareItemInv : CInventoryComponent ) : CScriptedFlashObject
{
    var result : CScriptedFlashObject;
    SBT_TagAllTierPiece( itemInvComponent, item );
    SBT_TagAllTierPiece( compareItemInv, compareWithItem );
    result = wrappedMethod( item, itemInvComponent, isShopItem, compareWithItem, compareItemInv );
    // Some tooltip replacements bypass AddSetAttributes or overwrite its
    // fields later. Reconcile the completed object through the same builder.
    SBT_WriteSetBlock( item, itemInvComponent, result );
    return result;
}
