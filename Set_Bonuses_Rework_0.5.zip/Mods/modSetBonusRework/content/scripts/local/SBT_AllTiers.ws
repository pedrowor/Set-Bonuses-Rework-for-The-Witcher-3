/* Enable existing set bonuses on every tier of recognised set equipment.
   School tags identify membership; SetBonusPiece makes vanilla count the item.
   Existing 3/6-piece thresholds and every bonus value remain unchanged. */

// Accept an explicit inventory component so item tooltips can also tag items
// outside the player's inventory without querying them through the wrong owner.
function SBT_TagAllTierPiece( inventory : CInventoryComponent, item : SItemUniqueId )
{
    var tags : array<name>;
    var i : int;
    if( !inventory || !inventory.IsIdValid( item ) ) return;

    // Repair membership before checking eligibility, including after a save load.
    if( SBT_IsManticoreProgressionItem( inventory.GetItemName( item ) ) )
    {
        if( !inventory.ItemHasTag( item, theGame.params.ITEM_SET_TAG_RED_WOLF ) )
            inventory.AddItemTag( item, theGame.params.ITEM_SET_TAG_RED_WOLF );
        if( !inventory.ItemHasTag( item, theGame.params.ITEM_SET_TAG_BONUS ) )
            inventory.AddItemTag( item, theGame.params.ITEM_SET_TAG_BONUS );
        return;
    }

    // Preserve the existing Viper fallback for items without a school tag.
    if( SBT_IsViperItem( inventory.GetItemName( item ) ) )
    {
        SBT_TagViperItem( inventory, item );
        return;
    }
    if( inventory.ItemHasTag( item, theGame.params.ITEM_SET_TAG_BONUS ) ) return;
    inventory.GetItemTags( item, tags );
    for( i = 0; i < tags.Size(); i += 1 )
    {
        switch( tags[i] )
        {
            case theGame.params.ITEM_SET_TAG_LYNX:
            case theGame.params.ITEM_SET_TAG_GRYPHON:
            case theGame.params.ITEM_SET_TAG_BEAR:
            case theGame.params.ITEM_SET_TAG_WOLF:
            case theGame.params.ITEM_SET_TAG_RED_WOLF:
            case theGame.params.ITEM_SET_TAG_VAMPIRE:
            case theGame.params.ITEM_SET_TAG_VIPER:
            case theGame.params.ITEM_SET_TAG_NETFLIX:
                inventory.AddItemTag( item, theGame.params.ITEM_SET_TAG_BONUS );
                return;
        }
    }
}

// Set membership comes only from four armor slots and two sword slots.
// Inventory items, quickslots, crossbows and duplicate references never count.
function SBT_SetEquipmentSlot( index : int ) : EEquipmentSlots
{
    switch( index )
    {
        case 0: return EES_Armor;
        case 1: return EES_Gloves;
        case 2: return EES_Boots;
        case 3: return EES_Pants;
        case 4: return EES_SteelSword;
        case 5: return EES_SilverSword;
    }
    return EES_InvalidSlot;
}

// This is deliberately read-only. Calling a recount from a count getter would
// recurse through ManageActiveSetBonuses -> IsSetBonusActive -> the getter.
@addMethod( W3PlayerWitcher ) function SBT_CountEquippedSetPieces( setType : EItemSetType ) : int
{
    var seen : array<SItemUniqueId>;
    var item : SItemUniqueId;
    var equipSlot : EEquipmentSlots;
    var i, count : int;
    if( !inv || setType == EIST_Undefined ) return 0;
    seen.Clear();
    count = 0;
    for( i = 0; i < 6; i += 1 )
    {
        equipSlot = SBT_SetEquipmentSlot( i );
        if( (int)equipSlot < itemSlots.Size() )
        {
            item = itemSlots[equipSlot];
            if( inv.IsIdValid( item ) && !seen.Contains( item ) )
            {
                seen.PushBack( item );
                if( CheckSetType( item ) == setType ) count += 1;
            }
        }
    }
    return count;
}

@addField( W3PlayerWitcher ) var sbtTierWarmup : float;
@addField( W3PlayerWitcher ) var sbtTierCheck : float;

// Rebuild from equipped item IDs instead of incrementing every tagged piece.
// This also repairs saved counts if a tooltip tagged an already-equipped item.
// Comparing complete counts makes repeated scans safe and prevents duplication.
@addMethod( W3PlayerWitcher ) function SBT_RefreshAllTierPieces()
{
    var counts : array<int>;
    var seen : array<SItemUniqueId>;
    var item : SItemUniqueId;
    var setType : EItemSetType;
    var equipSlot : EEquipmentSlots;
    var slot, i : int;

    if( !inv || amountOfSetPiecesEquipped.Size() == 0 ) return;
    counts.Clear();
    seen.Clear();
    counts.Resize( amountOfSetPiecesEquipped.Size() );
    for( i = 0; i < counts.Size(); i += 1 ) counts[i] = 0;
    for( slot = 0; slot < 6; slot += 1 )
    {
        equipSlot = SBT_SetEquipmentSlot( slot );
        if( (int)equipSlot >= itemSlots.Size() ) continue;
        item = itemSlots[equipSlot];
        if( inv.IsIdValid( item ) && !seen.Contains( item ) )
        {
            seen.PushBack( item );
            SBT_TagAllTierPiece( inv, item );
            if( inv.ItemHasTag( item, theGame.params.ITEM_SET_TAG_BONUS ) )
            {
                setType = CheckSetType( item );
                if( setType != EIST_Undefined && (int)setType < counts.Size() )
                    counts[setType] += 1;
            }
        }
    }
    for( i = 0; i < counts.Size(); i += 1 )
    {
        if( i != (int)EIST_Undefined && amountOfSetPiecesEquipped[i] != counts[i] )
        {
            amountOfSetPiecesEquipped[i] = counts[i];
            ManageActiveSetBonuses( (EItemSetType)i );
            ManageSetBonusesSoundbanks( (EItemSetType)i );
        }
    }
    SBT_ClearInactiveCharges();
}

// Wait until normal gameplay has been active for five seconds after loading.
// Equipment events handle new equips; the periodic scan handles existing saves.
// Keep early exits in a normal void helper. The timer event wrapper must
// preserve its boolean event result instead of returning an empty value.
@addMethod( W3PlayerWitcher ) function SBT_AllTiersTick( deltaTime : float )
{
    if( !theGame.IsActive() || theGame.IsBlackscreen() || theGame.IsFading() || !theGame.GetHud() )
    {
        sbtTierWarmup = 0.f;
        sbtTierCheck = 0.f;
        return;
    }
    if( sbtTierWarmup < 5.f )
    {
        sbtTierWarmup += deltaTime;
        return;
    }
    sbtTierCheck -= deltaTime;
    if( sbtTierCheck > 0.f ) return;
    sbtTierCheck = 2.f;
    SBT_RefreshAllTierPieces();
}

@wrapMethod( W3PlayerWitcher ) function OnPlayerTickTimer( deltaTime : float )
{
    var result : bool;
    result = wrappedMethod( deltaTime );
    SBT_ReworkMenuTick( deltaTime );
    SBT_AllTiersTick( deltaTime );
    return result;
}
