/* Charge consumption follows swing resolution and bomb throws, rather than
   counting every victim or grouping unrelated attacks into a time window. */
@addMethod( W3PlayerWitcher ) function SBT_BeginSwing( data : CPreAttackEventData, weapon : SItemUniqueId )
{
    var sword : bool;
    SBT_ClearInactiveCharges();
    sbtGrySwing = false;
    sbtBearSwing = false;
    sbtFwSwing = false;
    // CPreAttackEventData is an imported struct, not a nullable object.
    if( data.attackName == '' ) return;
    sword = inv.IsItemSteelSwordUsableByPlayer( weapon ) || inv.IsItemSilverSwordUsableByPlayer( weapon );
    // Recognised sword/fist melee attack ranges only; no crossbow or Sign attacks.
    if( !sword && !inv.IsItemFists( weapon ) ) return;
    if( SBT_On( SBT_GryResonanceBonus() ) && sbtGryHits > 0 )
    {
        sbtGrySwing = true;
        sbtGryHits -= 1;
    }
    if( SBT_On( EISB_Bear_2 ) && IsHeavyAttack( data.attackName ) &&
        sbtBearHits > 0 && theGame.GetEngineTimeAsSeconds() <= sbtBearExpire )
    {
        sbtBearSwing = true;
        sbtBearHits -= 1;
    }
    if( SBT_On( EISB_Netflix_2 ) )
    {
        if( sword && sbtFwAtkHits > 0 )
        {
            sbtFwSwing = true;
            sbtFwAtkHits -= 1;
        }
        sbtFwSignReady = true;
    }
}

// Use the normal function that resolves a swing and iterates its victims.
// Annotation wrappers require function declarations, not event declarations.
@wrapMethod( CR4Player ) function DoAttack( animData : CPreAttackEventData, weaponId : SItemUniqueId, parried : bool, countered : bool, parriedBy : array<CActor>, attackAnimationName : name, hitTime : float )
{
    var wp : W3PlayerWitcher;
    var previousGry, previousBear, previousFw : bool;
    wp = ( W3PlayerWitcher )this;
    if( wp )
    {
        previousGry = wp.sbtGrySwing;
        previousBear = wp.sbtBearSwing;
        previousFw = wp.sbtFwSwing;
    }
    if( wp ) wp.SBT_BeginSwing( animData, weaponId );
    wrappedMethod( animData, weaponId, parried, countered, parriedBy, attackAnimationName, hitTime );
    // All victims processed by this swing share one charge snapshot.
    if( wp )
    {
        wp.sbtGrySwing = previousGry;
        wp.sbtBearSwing = previousBear;
        wp.sbtFwSwing = previousFw;
    }
}

@wrapMethod( W3Petard ) function ThrowProjectile( targetPosIn : Vector )
{
    var wp : W3PlayerWitcher;
    wp = GetWitcherPlayer();
    sbtFwBomb = false;
    if( wp )
    {
        wp.SBT_ClearInactiveCharges();
        sbtFwSwitchId = wp.sbtFwSwitchId;
    }
    if( wp && GetOwner() == wp && SBT_On( EISB_Netflix_2 ) )
    {
        if( wp.sbtFwAtkHits > 0 )
        {
            sbtFwBomb = true;
            wp.sbtFwAtkHits -= 1;
        }
        wp.sbtFwSignReady = true;
    }
    wrappedMethod( targetPosIn );
}
