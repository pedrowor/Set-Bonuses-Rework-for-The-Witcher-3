/*
	English tooltips built in script (no w3strings needed). They replace the text in every
	language. SBT_CustomTooltips() false = vanilla text. Viper has no tooltip: vanilla has
	no bonus entries for it, so the game has nothing to show.
*/
function SBT_CustomTooltips() : bool { return true; }

function SBT_Pct( f : float ) : string
{
	return "" + RoundMath( f * 100 );
}

// percent with decimals, e.g. 0.0025 -> "0.25"
function SBT_PctDec( f : float ) : string
{
	return StrLeft( FloatToString( f * 100 ), 4 );
}

// plain number with one decimal, e.g. 0.5 -> "0.5"
function SBT_Num1( f : float ) : string
{
	return StrLeft( FloatToString( f ), 3 );
}

// the Resonance-style sentence shared by Gryphon 3pc/6pc
function SBT_GryResonanceText() : string
{
	return "After casting a Sign, the next " + SBT_GryResonanceHits() + " melee attacks deal additional damage equal to " + SBT_Pct( SBT_GryResonanceRatio() ) + "% Sign intensity.";
}

// User-specified descriptions. Do not edit wording without explicit instruction.
@wrapMethod( W3PlayerWitcher ) function GetSetBonusTooltipDescription( bonus : EItemSetBonus ) : string
{
    var vanillaDesc : string;
    vanillaDesc = wrappedMethod( bonus );
    if( !SBT_CustomTooltips() || !SBT_ReworkEnabled( SBT_BonusToSet( bonus ) ) ) return vanillaDesc;
    switch( bonus )
    {
        case EISB_Wolf_1:
            return "Each instance of Bleeding applied to enemies increases sword damage by 3% for each piece of the Set.";
        case EISB_Wolf_2:
            return "Each Adrenaline Point increases the possible number of Bleeding effects that can be applied to a single enemy. 5% Vitality Drain per bleed Instance.";
        case EISB_Bear_2:
            return "When a Quen shield shatters or when you take damage gain 0.5% Strong Attack Damage per 1% of Quen sign intensity for the next 2 heavy attacks, lasts 20 seconds.";
        case EISB_Gryphon_2:
            return "The size of Yrden traps is increased by 40%. While you are within an Yrden trap, Stamina regeneration is increased by 5/s and Sign Intensity by 100%, and damage taken is reduced by 20%. After casting a Sign, the next three melee attacks deal additional damage equal to 20% Sign intensity.";
        case EISB_RedWolf_2:
            return "Each point of Toxicity increases damage dealt by swords and Sign Intensity by 0.25%. Each point of Toxicity also increased damage dealt by bombs by +0.5%.";
        case EISB_Netflix_1:
            return "While Under the effect of any potions increase Sign Intensity and Attack Damage by 10% for each piece of the Set.";
        case EISB_Netflix_2:
            return "After using a sign your next 3 sword attack or bomb deals +50% more damage. After a Melee attack or a bomb throw increased sign intensity by 50%.";
        case EISB_Lynx_1:
            return "If the enemy is suffering from a Bleed and/or Poison increase your Critical Hit Chance by 3% and Critical Hit Damage by 6% for each piece of the Set.";
        case EISB_Lynx_2:
            return "2% Increased Light Attack Speed for each piece of the Set per Adrenaline Point";
    }
    // Bear, Griffin and Manticore 3pc retain the original description.
    return vanillaDesc;
}
