/*
	Damage-dealt effects. One wrap of ProcessDamageIncrease runs vanilla first, then each
	set's multiplier below. Multipliers stack multiplicatively with everything vanilla does.
*/

// ============================ CONFIG ============================
// Wolf 3pc (replaces vanilla 1%): damage per nearby enemy bleed instance, per piece.
function SBT_WolfBleedDmg() : float { return 0.03; }
// Maximum additional sword damage from Wolf 3pc: +144% (2.44 total multiplier).
function SBT_WolfBleedDmgCap() : float { return 1.44; }
// Viper 3pc: damage per piece against poisoned enemies, and against poison-immune enemies.
function SBT_ViperPoisonDmg() : float { return 0.05; }
function SBT_ViperImmuneDmg() : float { return 0.10; }
// Gryphon: which bonus carries the Resonance-style effect, its strength and length.
function SBT_GryResonanceBonus() : EItemSetBonus { return EISB_Gryphon_2; }	// EISB_Gryphon_1 = 3pc, EISB_Undefined = off
function SBT_GryResonanceRatio() : float { return 0.2; }	// bonus = sign intensity x this (vanilla skill: ratio x skill level)
function SBT_GryResonanceHits() : int { return 3; }

// Bear 6pc: attack bonus per 1 of sign intensity (0.5 = "0.5% attack per 1% sign").
function SBT_BearAttackPerIntensity() : float { return 0.5; }
function SBT_BearHits() : int { return 2; }
function SBT_BearTime() : float { return 20.f; }
// Forgotten Wolf 6pc: after a sign, the next N sword attacks/bombs get +bonus; after a melee attack/bomb, the next sign gets +bonus.
function SBT_FwAttackBonus() : float { return 0.5; }	// +50% damage
function SBT_FwAttackCount() : int { return 3; }
function SBT_FwSignBonus() : float { return 0.5; }		// +50% sign intensity

// Manticore 6pc: bomb damage per toxicity point (Volatile Compound style).
function SBT_RWBombPerToxicity() : float { return 0.005; }

// ============================ FIELDS ============================
@addField( W3PlayerWitcher ) var sbtGryHits : int;

@addField( W3PlayerWitcher ) var sbtBearHits : int;
@addField( W3PlayerWitcher ) var sbtBearBonus : float;
@addField( W3PlayerWitcher ) var sbtBearExpire : float;
@addField( W3PlayerWitcher ) var sbtBearSwing : bool;
@addField( W3PlayerWitcher ) var sbtFwAtkHits : int;

@addField( W3PlayerWitcher ) var sbtFwSwing : bool;
@addField( W3PlayerWitcher ) var sbtGrySwing : bool;
@addField( W3Petard ) var sbtFwBomb : bool;
@addField( W3PlayerWitcher ) var sbtFwSignReady : bool;

// ============================ HOOK ==============================
@wrapMethod( W3DamageManagerProcessor ) function ProcessDamageIncrease( out dmgInfos : array< SRawDamage > )
{
	// Remove a vanilla Cat 3pc buff carried over from an older save/version.
    if( action && !action.GetSimulateOnly() && GetWitcherPlayer() && SBT_ReworkEnabled( EIST_Lynx ) && GetWitcherPlayer().HasBuff( EET_LynxSetBonus ) )
        GetWitcherPlayer().RemoveBuff( EET_LynxSetBonus );
    wrappedMethod( dmgInfos );

	if( !GetWitcherPlayer() || !playerAttacker || !actorVictim || !action || playerVictim )
	{
		return;
	}

	SBT_DmgWolf( dmgInfos );
	SBT_DmgViper( dmgInfos );
	SBT_DmgGryphon( dmgInfos );
	SBT_DmgBear( dmgInfos );
	SBT_DmgForgottenWolf( dmgInfos );
	SBT_DmgManticore( dmgInfos );
}

// ---- Wolf 3pc: +3% per nearby enemy bleed per piece -----------------------
@addMethod( W3DamageManagerProcessor ) function SBT_DmgWolf( out dmgInfos : array< SRawDamage > )
{
	var n : int;

	if( SBT_IsSwordAttack( attackAction ) && SBT_On( EISB_Wolf_1 ) )
	{
		n = SBT_CountNearbyEnemyBleeds();
		if( n > 0 )
		{
			SBT_Mult( dmgInfos, 1.f + MinF( SBT_WolfBleedDmgCap(), n * GetWitcherPlayer().GetSetPartsEquipped( EIST_Wolf ) * SBT_WolfBleedDmg() ) );
		}
	}
}

// ---- Viper 3pc: more damage to poisoned enemies ----------------------------
@addMethod( W3DamageManagerProcessor ) function SBT_DmgViper( out dmgInfos : array< SRawDamage > )
{
    var mult : float;
    var poisoned, immune, active : bool;
    if( action.IsDoTDamage() || !SBT_IsSwordAttack( attackAction ) ) return;
    active = SBT_ViperOn1();
    poisoned = SBT_IsPoisoned( actorVictim );
    immune = actorVictim.IsImmuneToBuff( EET_Poison );
    mult = 1.f;
    if( active )
    {
        if( poisoned ) mult += SBT_ViperPoisonDmg() * SBT_ViperPieces();
        else if( immune ) mult += SBT_ViperImmuneDmg() * SBT_ViperPieces();
        if( mult > 1.f ) SBT_Mult( dmgInfos, mult );
    }

}

// ---- Gryphon: Resonance-style bonus that stacks with the real skill ---------
@addMethod( W3DamageManagerProcessor ) function SBT_DmgGryphon( out dmgInfos : array< SRawDamage > )
{
    var wp : W3PlayerWitcher;
    var sp : SAbilityAttributeValue;
    wp = GetWitcherPlayer();
    if( attackAction && attackAction.IsActionMelee() && wp.sbtGrySwing && SBT_On( SBT_GryResonanceBonus() ) )
    {
        sp = wp.GetPowerStatValue( CPS_SpellPower );
        SBT_Mult( dmgInfos, 1 + MaxF( 0.f, sp.valueMultiplicative ) * SBT_GryResonanceRatio() );
    }
}

@addMethod( W3DamageManagerProcessor ) function SBT_DmgBear( out dmgInfos : array< SRawDamage > )
{
    var wp : W3PlayerWitcher;
    wp = GetWitcherPlayer();
    if( attackAction && attackAction.IsActionMelee() && wp.sbtBearSwing &&
        playerAttacker.IsHeavyAttack( attackAction.GetAttackName() ) && SBT_On( EISB_Bear_2 ) )
    {
        SBT_Mult( dmgInfos, 1 + wp.sbtBearBonus );
    }
}

@addMethod( W3DamageManagerProcessor ) function SBT_DmgForgottenWolf( out dmgInfos : array< SRawDamage > )
{
    var wp : W3PlayerWitcher;
    var petard : W3Petard;
    var boost : bool;
    if( action.IsDoTDamage() || !SBT_On( EISB_Netflix_2 ) ) return;
    wp = GetWitcherPlayer();
    petard = ( W3Petard )action.causer;
    if( petard ) boost = petard.sbtFwBomb && petard.sbtFwSwitchId == wp.sbtFwSwitchId;
    else if( SBT_IsSwordAttack( attackAction ) ) boost = wp.sbtFwSwing;
    if( boost ) SBT_Mult( dmgInfos, 1 + SBT_FwAttackBonus() );
}

// ---- Manticore 6pc: bombs hit harder with toxicity --------------------------
@addMethod( W3DamageManagerProcessor ) function SBT_DmgManticore( out dmgInfos : array< SRawDamage > )
{
    if( (W3Petard)action.causer && !action.IsDoTDamage() && SBT_On( EISB_RedWolf_2 ) )
        SBT_Mult( dmgInfos, 1.f + MaxF( 0.f, GetWitcherPlayer().GetStat( BCS_Toxicity ) ) * SBT_RWBombPerToxicity() );
}

// Cat critical damage belongs in the attack power modifier, where vanilla also
// adds critical damage. This uses this hit's actual victim, never the lock target.
@wrapMethod( W3DamageManagerProcessor ) function GetAttackersPowerMod() : SAbilityAttributeValue
{
    var result, resistance : SAbilityAttributeValue;
    var manticoreBonus : float;
    var wp : W3PlayerWitcher;
    result = wrappedMethod();
    if( playerAttacker && SBT_IsSwordAttack( attackAction ) )
    {
        wp = GetWitcherPlayer();
        if( SBT_On( EISB_RedWolf_2 ) )
        {
            manticoreBonus = MaxF( 0.f, wp.GetStat( BCS_Toxicity ) ) * SBT_EuphoriaPerPoint();
            result.valueMultiplicative += manticoreBonus;
        }

    }
    if( playerAttacker && SBT_IsSwordAttack( attackAction ) && actorVictim &&
        action.IsCriticalHit() && SBT_On( EISB_Lynx_1 ) && SBT_CatTarget( actorVictim ) )
    {
        resistance = actorVictim.GetAttributeValue( theGame.params.CRITICAL_HIT_REDUCTION );
        result.valueMultiplicative += 0.06 * GetWitcherPlayer().GetSetPartsEquipped( EIST_Lynx ) * SBT_CatStatusCount( actorVictim ) *
            ClampF( 1 - resistance.valueMultiplicative, 0.f, 1.f );
    }
    return result;
}
