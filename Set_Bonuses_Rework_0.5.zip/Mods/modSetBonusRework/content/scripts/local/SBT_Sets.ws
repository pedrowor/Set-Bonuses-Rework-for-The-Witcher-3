/*
	Non-damage-dealt effects: power stats, signs, damage taken, crits, lifesteal.
*/

// ============================ CONFIG ============================
// Manticore 6pc "small Euphoria": attack power and sign intensity per toxicity point (vanilla Mutation 10 = 0.0075).
function SBT_EuphoriaPerPoint() : float { return 0.0025; }
// Forgotten Wolf 3pc: attack power and sign intensity per piece while any potion is active.
function SBT_FwPotionBonus() : float { return 0.10; }
// Wolf 6pc: share of melee damage healed, per bleed instance on the target.
function SBT_WolfLifesteal() : float { return 0.05; }
// Maximum share of qualifying damage restored as vitality, regardless of stacks.
function SBT_WolfLifestealCap() : float { return 0.20; }

// Viper 6pc, by oil level (1 standard, 2 enhanced, 3 superior); all bonuses are PER EQUIPPED VIPER SET PIECE.
function SBT_ViperCritChance( lvl : int ) : float { if( lvl >= 3 ) return 0.05; if( lvl == 2 ) return 0.03; if( lvl == 1 ) return 0.01; return 0; }
function SBT_ViperCritDamage( lvl : int ) : float { if( lvl >= 3 ) return 0.10; if( lvl == 2 ) return 0.05; if( lvl == 1 ) return 0.05; return 0; }
function SBT_ViperDmgTaken( lvl : int ) : float   { if( lvl >= 3 ) return 0.04; if( lvl == 2 ) return 0.02; if( lvl == 1 ) return 0.01; return 0; }

// Shared additions to general power and per-Sign power are independent queries.
function SBT_AddPowerBonuses( out value : SAbilityAttributeValue, signPower : bool )
{
    var wp : W3PlayerWitcher;
    wp = GetWitcherPlayer();
    if( !wp ) return;
    if( signPower && SBT_On( EISB_RedWolf_2 ) )
        value.valueMultiplicative += MaxF( 0.f, wp.GetStat( BCS_Toxicity ) ) * SBT_EuphoriaPerPoint();
    if( SBT_On( EISB_Netflix_1 ) && SBT_HasPotionBuff() )
        value.valueMultiplicative += SBT_FwPotionBonus() * wp.GetSetPartsEquipped( EIST_Netflix );
}

@wrapMethod( W3PlayerWitcher ) function GetPowerStatValue( stat : ECharacterPowerStats, optional ablName : name, optional ignoreDeath : bool ) : SAbilityAttributeValue
{
    var result : SAbilityAttributeValue;
    result = wrappedMethod( stat, ablName, ignoreDeath );
    if( stat == CPS_AttackPower || stat == CPS_SpellPower )
        SBT_AddPowerBonuses( result, stat == CPS_SpellPower );
    if( stat == CPS_AttackPower && sbtManticoreStatsPreview && SBT_On( EISB_RedWolf_2 ) )
        result.valueMultiplicative += MaxF( 0.f, GetStat( BCS_Toxicity ) ) * SBT_EuphoriaPerPoint();
    return result;
}

@wrapMethod( W3PlayerWitcher ) function GetTotalSignSpellPower( signSkill : ESkill ) : SAbilityAttributeValue
{
    var result : SAbilityAttributeValue;
    result = wrappedMethod( signSkill );
    SBT_AddPowerBonuses( result, true );
    if( sbtFwSignReady && SBT_On( EISB_Netflix_2 ) )
        result.valueMultiplicative += SBT_FwSignBonus();
    return result;
}

@wrapMethod( W3PlayerWitcher ) function OnSignCastPerformed( signType : ESignType, isAlternate : bool )
{
    SBT_ClearInactiveCharges();
    wrappedMethod( signType, isAlternate );
    if( SBT_On( SBT_GryResonanceBonus() ) ) sbtGryHits = SBT_GryResonanceHits();
    if( SBT_On( EISB_Netflix_2 ) )
    {
        sbtFwSignReady = false;
        sbtFwAtkHits = SBT_FwAttackCount();
    }
}

// The protection uses the currently held sword and the incoming actor's category.
@wrapMethod( W3PlayerWitcher ) function ReduceDamage( out damageData : W3DamageAction )
{
    var attacker : CActor;
    var reduction : float;
    wrappedMethod( damageData );
    if( damageData.victim != this || damageData.IsDoTDamage() || !SBT_ViperOn2() ) return;
    attacker = (CActor)damageData.attacker;
    if( attacker && attacker != this && SBT_IsPoisoned( attacker ) )
    {
        reduction = ClampF( SBT_ViperDmgTaken( SBT_HeldOilLevel( SBT_ActorCategory( attacker ) ) ) * SBT_ViperPieces(), 0.f, 1.f );
        damageData.processedDmg.vitalityDamage *= 1.f - reduction;
        damageData.processedDmg.essenceDamage *= 1.f - reduction;
    }
}

@wrapMethod( W3PlayerWitcher ) function GetCriticalHitChance( isLightAttack : bool, isHeavyAttack : bool, target : CActor, victimMonsterCategory : EMonsterCategory, isBolt : bool ) : float
{
    var result : float;
    var weapon : SItemUniqueId;
    result = wrappedMethod( isLightAttack, isHeavyAttack, target, victimMonsterCategory, isBolt );
    weapon = SBT_CriticalWeapon();
    if( !isBolt && ( isLightAttack || isHeavyAttack ) &&
        ( inv.IsItemSteelSwordUsableByPlayer( weapon ) || inv.IsItemSilverSwordUsableByPlayer( weapon ) ) )
    {
        if( SBT_ViperOn2() )
            result += SBT_ViperCritChance( SBT_OilLevelOnItem( weapon, victimMonsterCategory, true ) ) * SBT_ViperPieces();
        if( SBT_On( EISB_Lynx_1 ) )
            result += 0.03 * GetSetPartsEquipped( EIST_Lynx ) * SBT_CatStatusCount( target );
    }
    return result;
}

@wrapMethod( W3PlayerWitcher ) function GetCriticalHitDamageBonus( weaponId : SItemUniqueId, victimMonsterCategory : EMonsterCategory, isStrikeAtBack : bool ) : SAbilityAttributeValue
{
    var result : SAbilityAttributeValue;
    result = wrappedMethod( weaponId, victimMonsterCategory, isStrikeAtBack );
    if( SBT_ViperOn2() && ( inv.IsItemSteelSwordUsableByPlayer( weaponId ) || inv.IsItemSilverSwordUsableByPlayer( weaponId ) ) )
        result.valueAdditive += SBT_ViperCritDamage( SBT_OilLevelOnItem( weaponId, victimMonsterCategory, true ) ) * SBT_ViperPieces();
    return result;
}
