Set Bonuses Rework

Set Bonuses that are changed for now - Bear / Griffin / Manticore / Wolf / Viper / Forgotten Wolf
Remastered 5.x, annotation-only (no vanilla script files replaced)

How to Install > simply copy Mods/modSetBonusRework into <Witcher 3>/mods/ or use TW3 Mod Manager.

WHAT EACH SET DOES:
Wolf School 3pc - Each instance of Bleeding applied to enemies increases sword damage by 3% for each piece of the Set.
Wolf School 6pc - Each Adrenaline Point increases the possible number of Bleeding effects that can be applied to a single enemy. 5% Vitality Drain per bleed Instance.

Bear School 3pc - Vanilla
Bear School 6pc - When a Quen shield shatters or when you take damage gain 0.5% Strong Attack Damage per 1% of Quen sign intensity for the next 2 heavy attacks, lasts 20 seconds.

Griffin School 3pc - Vanilla
Griffin School 6pc - The size of Yrden traps is increased by 40%. 
                     While you are within an Yrden trap, Stamina regeneration is increased by 5/s and Sign Intensity by 100%, and damage taken is reduced by 20%.
                     After casting a Sign, the next three melee attacks deal additional damage equal to 20% Sign intensity.

Manticore School 3pc - Vanilla
Manticore School 6pc - Each point of Toxicity increases damage dealt by swords and Sign Intensity by 0.25%.
                       Each point of Toxicity also increased damage dealt by bombs by +0.5%.
                    
Forgotten Wolf Set 3pc - While Under the effect of any potions increase Sign Intensity and Attack Damage by 10% for each piece of the Set.
Forgotten Wolf Set 6pc - After using a sign your next 3 sword attack or bomb deals +50% more damage.
                         After a Melee attack or a bomb throw increased sign intensity by 50%.

Viper School 3pc - Poisoned weapons deal +5% additional damage or 10% against poison-immune targets for each piece of the Set.
Viper School 6pc - If using the appropriate oil gain additional 1%/3%/5% Critical Chance, 5%/5%/10% Critical Damage and Take 1%/2%/4% Damage from Poisoned Enemies.
                   Bonuses scale with the level of the oil, Standard Oil/Enchanced Oil/Superior Oil.

Cat School 3pc - If the enemy is suffering from a Bleed and/or Poison increase your Critical Hit Chance by 3% and Critical Hit Damage by 6% for each piece of the Set.
Cat School 6pc - 2% Increased Light Attack Speed for each piece of the Set per Adrenaline Point.

to-do:
introduce more potion effects into manticore, potion effectviness per piece of the set if possible.
maybe make viper disable poison immunity, not sure if possible.
forgotten wolf better mix of everything, better incentive to mix things up.
wolf school better bleed chance for those who don't use skill tree reforged.
bear school also takes account vitality or have some sort vitality regen effect after quen breaking
general balance for a equal base from all sets.



changelog
=========

0.3
- Added Cat School Rework
- Reverted Griffin School Yrden bonuses for now
- Enabled set bonuses for every tier of equipment carrying a recognised school/set tag, including lower tiers and their New Game Plus equivalents.

0.4
- Added seven On/Off switches under Options > Mods > Set Bonuses Rework
- All switches default to ON. Each switch controls the whole rework (both 3pc and 6pc). OFF restores the original game/Remaster bonuses for that school.

0.5
- Fix some bugs in the code and how the effects were working, it should be cleaner now.
- Improved UI compatability
- Improved how the set effects were showing so there will be no duplicates and no leftovers from equip and unequip the sets.

0.5.1
- Capped Wolf 3pc's additional sword damage at +144% (a maximum 2.44 multiplier from this bonus). It still counts supported bleed instances across nearby living hostile NPCs. At six pieces, eight nearby bleed instances reach the cap.
- Capped Wolf 6pc vitality drain at 20% of qualifying damage. Drain continues to count bleeds only on the enemy hit, not every nearby enemy. It remains 5% per bleed, with the existing actual-health-loss/overkill limit. Four target bleeds reach the cap.
- Added read-only bonus counters beneath the existing set descriptions. Wolf shows current nearby-bleed damage, per-instance equipped-piece scaling, caps and adrenaline-based bleed capacity. Bear shows stored bonus, remaining attacks and expiry. Griffin shows charged melee bonus, attacks remaining and native Yrden buff status. Manticore shows current toxicity-based sword power, Sign Intensity and bomb damage. Forgotten Wolf shows potion-based totals, sword/bomb charges and the readied Sign bonus. Cat shows conditional one-status/two-status critical totals and current adrenaline-based light-sword speed. Viper shows conditional equipped-piece damage totals and standard/enhanced/superior matching-oil totals.
- Target-dependent bonuses are labelled conditional, not represented as permanently active stats. No arbitrary target is selected by inspecting an item. A counter showing readied Forgotten Wolf Sign power does not resolve the previously identified delayed-cast timing issue.
- Below the required piece threshold, reworked bonuses show an inactive counter. Rework OFF retains native text without added custom counters. Unchanged native 3pc bonuses retain their native numerical descriptions. Counters are snapshots refreshed when the tooltip is constructed, not a live combat HUD. The original description strings are used afresh on each rebuild so counter lines do not accumulate.
- Counter values describe this mod's contribution, not final damage after every skill, resistance or other mod. Sword attack-power additions are labelled accordingly. Display percentages round to two decimal places; gameplay uses unrounded values.
